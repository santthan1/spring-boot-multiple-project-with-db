https://www.youtube.com/watch?v=PUXP9dVdtFM
https://www.youtube.com/watch?v=2i67Qhff_pI

https://plugins.jetbrains.com/plugin/14200-entity-spring-rest-code-generator

