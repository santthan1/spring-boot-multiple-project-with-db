package in.sf.wcl.ps.wclps;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WclpsApplicationTests {

	@Test
	void contextLoads() {
	}

}
