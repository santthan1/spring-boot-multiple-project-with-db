package in.sf.wcl.entity;

import java.io.Serializable;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the PS_TB_COM_PYMT_REQ_HDR database table.
 * 
 */
@Entity
@Table(name="PS_TB_COM_PYMT_REQ_HDR")
@NamedQuery(name="PsTbComPymtReqHdr.findAll", query="SELECT p FROM PsTbComPymtReqHdr p")
public class PsTbComPymtReqHdr implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="PYMT_REQ_HDR_ID")
	private long pymtReqHdrId;

	@Column(name="ACTION_TYPE_CODE")
	private String actionTypeCode;

	@Column(name="ADDR_SLNO")
	private BigDecimal addrSlno;

	@Column(name="ADJ_AMT")
	private BigDecimal adjAmt;

	@Column(name="ADJ_DEALER_CODE")
	private String adjDealerCode;

	@Column(name="ADVICE_BOOK_ID")
	private String adviceBookId;

	@Column(name="ADVICE_BRANCH_CODE")
	private String adviceBranchCode;

	@Temporal(TemporalType.DATE)
	@Column(name="ADVICE_DATE")
	private Date adviceDate;

	@Column(name="ADVICE_LEDGER_HDR_ID")
	private BigDecimal adviceLedgerHdrId;

	@Column(name="ADVICE_NO")
	private BigDecimal adviceNo;

	@Column(name="APPLICATION_CODE")
	private String applicationCode;

	@Column(name="AUDIT_LOG")
	private Object auditLog;

	@Column(name="AUTH_CTRL_IND")
	private String authCtrlInd;

	@Column(name="AUTH_DTLS")
	private Object authDtls;

	@Column(name="BENIFICIARY_ACCT_NO")
	private String benificiaryAcctNo;

	@Column(name="BENIFICIARY_ACCT_TYPE_CODE")
	private BigDecimal benificiaryAcctTypeCode;

	@Column(name="BENIFICIARY_BANK_BRANCH_ID")
	private BigDecimal benificiaryBankBranchId;

	@Temporal(TemporalType.DATE)
	@Column(name="BILL_DATE")
	private Date billDate;

	@Column(name="BILL_NUMBER")
	private String billNumber;

	@Temporal(TemporalType.DATE)
	@Column(name="CANCEL_DATE")
	private Date cancelDate;

	@Column(name="CANCEL_REMARKS")
	private String cancelRemarks;

	@Column(name="CHARGES_TO")
	private String chargesTo;

	@Column(name="CHARGES_TYPE")
	private String chargesType;

	@Column(name="CHRGS_BANK")
	private BigDecimal chrgsBank;

	@Column(name="CHRGS_CUSTOMER")
	private BigDecimal chrgsCustomer;

	@Column(name="COMPANY_CODE")
	private String companyCode;

	@Column(name="CONTACT_CODE")
	private String contactCode;

	@Column(name="CONTACT_ID")
	private BigDecimal contactId;

	@Column(name="CONTACT_ROLE")
	private String contactRole;

	@Column(name="CURRENCY_CODE")
	private String currencyCode;

	@Column(name="DD_PLACE_ID")
	private BigDecimal ddPlaceId;

	@Column(name="DEDN_AMT")
	private BigDecimal dednAmt;

	@Column(name="DISCOUNT_TYPE")
	private String discountType;

	@Column(name="DRAWEE_PLACE")
	private String draweePlace;

	@Temporal(TemporalType.DATE)
	@Column(name="END_TIME")
	private Date endTime;

	@Column(name="FAVOURING_NAME")
	private String favouringName;

	@Column(name="FAVOURING_NAME_OPTION")
	private String favouringNameOption;

	@Column(name="GST_INCL_EXCL_IND")
	private String gstInclExclInd;

	@Column(name="GST_INVOICE_TAX_TYPE")
	private String gstInvoiceTaxType;

	@Column(name="GST_LINK_ID")
	private BigDecimal gstLinkId;

	@Column(name="GST_NUMBER")
	private String gstNumber;

	@Column(name="GST_REVERSE_TAX_APPL")
	private String gstReverseTaxAppl;

	@Column(name="GST_SESSION_ID")
	private BigDecimal gstSessionId;

	@Column(name="GST_TAX_AMT")
	private BigDecimal gstTaxAmt;

	@Column(name="GST_WH_HID")
	private BigDecimal gstWhHid;

	@Column(name="GST_WH_REQ_STATUS")
	private String gstWhReqStatus;

	@Column(name="IFSC_CODE")
	private String ifscCode;

	@Column(name="INST_TYPE")
	private String instType;

	@Column(name="LETTER_PRINT_IND")
	private String letterPrintInd;

	@Column(name="MASTER_POLICY_NO")
	private String masterPolicyNo;

	@Column(name="MICR_CODE")
	private String micrCode;

	@Column(name="MODIFIED_GST_NUMBER")
	private String modifiedGstNumber;

	@Column(name="MODULE_CODE")
	private String moduleCode;

	@Column(name="NET_AMT")
	private BigDecimal netAmt;

	@Column(name="PR_TYPE")
	private BigDecimal prType;

	@Column(name="PREFERED_BANK_CODE")
	private String preferedBankCode;

	@Column(name="PREFERED_BANK_ID")
	private BigDecimal preferedBankId;

	@Column(name="PREFERED_BANK_NAME")
	private String preferedBankName;

	@Column(name="PRINT_COUNT")
	private BigDecimal printCount;

	@Temporal(TemporalType.DATE)
	@Column(name="PRINT_DATE")
	private Date printDate;

	@Column(name="PRINTED_BY")
	private String printedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="PYMT_DATE")
	private Date pymtDate;

	@Column(name="PYMT_TO")
	private String pymtTo;

	@Column(name="PYMT_TYPE")
	private String pymtType;

	@Temporal(TemporalType.DATE)
	@Column(name="RCPT_UPTO")
	private Date rcptUpto;

	@Column(name="REQ_BOOK_ID")
	private String reqBookId;

	@Column(name="REQ_BRANCH_CODE")
	private String reqBranchCode;

	@Temporal(TemporalType.DATE)
	@Column(name="REQ_DATE")
	private Date reqDate;

	@Column(name="REQ_DOC_TYPE_ABBR")
	private String reqDocTypeAbbr;

	@Column(name="REQ_NO")
	private BigDecimal reqNo;

	@Column(name="REQ_STATUS")
	private String reqStatus;

	@Column(name="REQ_TXN_AMT")
	private BigDecimal reqTxnAmt;

	@Column(name="SEC_206AB_APPL_IND")
	private String sec206abApplInd;

	@Column(name="SEC_206AB_EXEMP_RATE")
	private BigDecimal sec206abExempRate;

	@Column(name="SEC_206AB_RATE")
	private BigDecimal sec206abRate;

	@Column(name="SERVICE_TAX_AMOUNT")
	private BigDecimal serviceTaxAmount;

	@Column(name="SF_GSTN")
	private String sfGstn;

	@Column(name="SP_INVOICE_NO")
	private String spInvoiceNo;

	@Temporal(TemporalType.DATE)
	@Column(name="START_TIME")
	private Date startTime;

	@Column(name="VOUCHER_BOOK_ID")
	private String voucherBookId;

	@Column(name="VOUCHER_BRANCH_CODE")
	private String voucherBranchCode;

	@Temporal(TemporalType.DATE)
	@Column(name="VOUCHER_DATE")
	private Date voucherDate;

	@Column(name="VOUCHER_LEDGER_HDR_ID")
	private BigDecimal voucherLedgerHdrId;

	@Column(name="VOUCHER_NO")
	private BigDecimal voucherNo;

	//bi-directional many-to-one association to PsTbComPymtReqDtl
	@OneToMany(mappedBy="psTbComPymtReqHdr")
	private List<PsTbComPymtReqDtl> psTbComPymtReqDtls;

	public PsTbComPymtReqHdr() {
	}

	public long getPymtReqHdrId() {
		return this.pymtReqHdrId;
	}

	public void setPymtReqHdrId(long pymtReqHdrId) {
		this.pymtReqHdrId = pymtReqHdrId;
	}

	public String getActionTypeCode() {
		return this.actionTypeCode;
	}

	public void setActionTypeCode(String actionTypeCode) {
		this.actionTypeCode = actionTypeCode;
	}

	public BigDecimal getAddrSlno() {
		return this.addrSlno;
	}

	public void setAddrSlno(BigDecimal addrSlno) {
		this.addrSlno = addrSlno;
	}

	public BigDecimal getAdjAmt() {
		return this.adjAmt;
	}

	public void setAdjAmt(BigDecimal adjAmt) {
		this.adjAmt = adjAmt;
	}

	public String getAdjDealerCode() {
		return this.adjDealerCode;
	}

	public void setAdjDealerCode(String adjDealerCode) {
		this.adjDealerCode = adjDealerCode;
	}

	public String getAdviceBookId() {
		return this.adviceBookId;
	}

	public void setAdviceBookId(String adviceBookId) {
		this.adviceBookId = adviceBookId;
	}

	public String getAdviceBranchCode() {
		return this.adviceBranchCode;
	}

	public void setAdviceBranchCode(String adviceBranchCode) {
		this.adviceBranchCode = adviceBranchCode;
	}

	public Date getAdviceDate() {
		return this.adviceDate;
	}

	public void setAdviceDate(Date adviceDate) {
		this.adviceDate = adviceDate;
	}

	public BigDecimal getAdviceLedgerHdrId() {
		return this.adviceLedgerHdrId;
	}

	public void setAdviceLedgerHdrId(BigDecimal adviceLedgerHdrId) {
		this.adviceLedgerHdrId = adviceLedgerHdrId;
	}

	public BigDecimal getAdviceNo() {
		return this.adviceNo;
	}

	public void setAdviceNo(BigDecimal adviceNo) {
		this.adviceNo = adviceNo;
	}

	public String getApplicationCode() {
		return this.applicationCode;
	}

	public void setApplicationCode(String applicationCode) {
		this.applicationCode = applicationCode;
	}

	public Object getAuditLog() {
		return this.auditLog;
	}

	public void setAuditLog(Object auditLog) {
		this.auditLog = auditLog;
	}

	public String getAuthCtrlInd() {
		return this.authCtrlInd;
	}

	public void setAuthCtrlInd(String authCtrlInd) {
		this.authCtrlInd = authCtrlInd;
	}

	public Object getAuthDtls() {
		return this.authDtls;
	}

	public void setAuthDtls(Object authDtls) {
		this.authDtls = authDtls;
	}

	public String getBenificiaryAcctNo() {
		return this.benificiaryAcctNo;
	}

	public void setBenificiaryAcctNo(String benificiaryAcctNo) {
		this.benificiaryAcctNo = benificiaryAcctNo;
	}

	public BigDecimal getBenificiaryAcctTypeCode() {
		return this.benificiaryAcctTypeCode;
	}

	public void setBenificiaryAcctTypeCode(BigDecimal benificiaryAcctTypeCode) {
		this.benificiaryAcctTypeCode = benificiaryAcctTypeCode;
	}

	public BigDecimal getBenificiaryBankBranchId() {
		return this.benificiaryBankBranchId;
	}

	public void setBenificiaryBankBranchId(BigDecimal benificiaryBankBranchId) {
		this.benificiaryBankBranchId = benificiaryBankBranchId;
	}

	public Date getBillDate() {
		return this.billDate;
	}

	public void setBillDate(Date billDate) {
		this.billDate = billDate;
	}

	public String getBillNumber() {
		return this.billNumber;
	}

	public void setBillNumber(String billNumber) {
		this.billNumber = billNumber;
	}

	public Date getCancelDate() {
		return this.cancelDate;
	}

	public void setCancelDate(Date cancelDate) {
		this.cancelDate = cancelDate;
	}

	public String getCancelRemarks() {
		return this.cancelRemarks;
	}

	public void setCancelRemarks(String cancelRemarks) {
		this.cancelRemarks = cancelRemarks;
	}

	public String getChargesTo() {
		return this.chargesTo;
	}

	public void setChargesTo(String chargesTo) {
		this.chargesTo = chargesTo;
	}

	public String getChargesType() {
		return this.chargesType;
	}

	public void setChargesType(String chargesType) {
		this.chargesType = chargesType;
	}

	public BigDecimal getChrgsBank() {
		return this.chrgsBank;
	}

	public void setChrgsBank(BigDecimal chrgsBank) {
		this.chrgsBank = chrgsBank;
	}

	public BigDecimal getChrgsCustomer() {
		return this.chrgsCustomer;
	}

	public void setChrgsCustomer(BigDecimal chrgsCustomer) {
		this.chrgsCustomer = chrgsCustomer;
	}

	public String getCompanyCode() {
		return this.companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getContactCode() {
		return this.contactCode;
	}

	public void setContactCode(String contactCode) {
		this.contactCode = contactCode;
	}

	public BigDecimal getContactId() {
		return this.contactId;
	}

	public void setContactId(BigDecimal contactId) {
		this.contactId = contactId;
	}

	public String getContactRole() {
		return this.contactRole;
	}

	public void setContactRole(String contactRole) {
		this.contactRole = contactRole;
	}

	public String getCurrencyCode() {
		return this.currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public BigDecimal getDdPlaceId() {
		return this.ddPlaceId;
	}

	public void setDdPlaceId(BigDecimal ddPlaceId) {
		this.ddPlaceId = ddPlaceId;
	}

	public BigDecimal getDednAmt() {
		return this.dednAmt;
	}

	public void setDednAmt(BigDecimal dednAmt) {
		this.dednAmt = dednAmt;
	}

	public String getDiscountType() {
		return this.discountType;
	}

	public void setDiscountType(String discountType) {
		this.discountType = discountType;
	}

	public String getDraweePlace() {
		return this.draweePlace;
	}

	public void setDraweePlace(String draweePlace) {
		this.draweePlace = draweePlace;
	}

	public Date getEndTime() {
		return this.endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public String getFavouringName() {
		return this.favouringName;
	}

	public void setFavouringName(String favouringName) {
		this.favouringName = favouringName;
	}

	public String getFavouringNameOption() {
		return this.favouringNameOption;
	}

	public void setFavouringNameOption(String favouringNameOption) {
		this.favouringNameOption = favouringNameOption;
	}

	public String getGstInclExclInd() {
		return this.gstInclExclInd;
	}

	public void setGstInclExclInd(String gstInclExclInd) {
		this.gstInclExclInd = gstInclExclInd;
	}

	public String getGstInvoiceTaxType() {
		return this.gstInvoiceTaxType;
	}

	public void setGstInvoiceTaxType(String gstInvoiceTaxType) {
		this.gstInvoiceTaxType = gstInvoiceTaxType;
	}

	public BigDecimal getGstLinkId() {
		return this.gstLinkId;
	}

	public void setGstLinkId(BigDecimal gstLinkId) {
		this.gstLinkId = gstLinkId;
	}

	public String getGstNumber() {
		return this.gstNumber;
	}

	public void setGstNumber(String gstNumber) {
		this.gstNumber = gstNumber;
	}

	public String getGstReverseTaxAppl() {
		return this.gstReverseTaxAppl;
	}

	public void setGstReverseTaxAppl(String gstReverseTaxAppl) {
		this.gstReverseTaxAppl = gstReverseTaxAppl;
	}

	public BigDecimal getGstSessionId() {
		return this.gstSessionId;
	}

	public void setGstSessionId(BigDecimal gstSessionId) {
		this.gstSessionId = gstSessionId;
	}

	public BigDecimal getGstTaxAmt() {
		return this.gstTaxAmt;
	}

	public void setGstTaxAmt(BigDecimal gstTaxAmt) {
		this.gstTaxAmt = gstTaxAmt;
	}

	public BigDecimal getGstWhHid() {
		return this.gstWhHid;
	}

	public void setGstWhHid(BigDecimal gstWhHid) {
		this.gstWhHid = gstWhHid;
	}

	public String getGstWhReqStatus() {
		return this.gstWhReqStatus;
	}

	public void setGstWhReqStatus(String gstWhReqStatus) {
		this.gstWhReqStatus = gstWhReqStatus;
	}

	public String getIfscCode() {
		return this.ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	public String getInstType() {
		return this.instType;
	}

	public void setInstType(String instType) {
		this.instType = instType;
	}

	public String getLetterPrintInd() {
		return this.letterPrintInd;
	}

	public void setLetterPrintInd(String letterPrintInd) {
		this.letterPrintInd = letterPrintInd;
	}

	public String getMasterPolicyNo() {
		return this.masterPolicyNo;
	}

	public void setMasterPolicyNo(String masterPolicyNo) {
		this.masterPolicyNo = masterPolicyNo;
	}

	public String getMicrCode() {
		return this.micrCode;
	}

	public void setMicrCode(String micrCode) {
		this.micrCode = micrCode;
	}

	public String getModifiedGstNumber() {
		return this.modifiedGstNumber;
	}

	public void setModifiedGstNumber(String modifiedGstNumber) {
		this.modifiedGstNumber = modifiedGstNumber;
	}

	public String getModuleCode() {
		return this.moduleCode;
	}

	public void setModuleCode(String moduleCode) {
		this.moduleCode = moduleCode;
	}

	public BigDecimal getNetAmt() {
		return this.netAmt;
	}

	public void setNetAmt(BigDecimal netAmt) {
		this.netAmt = netAmt;
	}

	public BigDecimal getPrType() {
		return this.prType;
	}

	public void setPrType(BigDecimal prType) {
		this.prType = prType;
	}

	public String getPreferedBankCode() {
		return this.preferedBankCode;
	}

	public void setPreferedBankCode(String preferedBankCode) {
		this.preferedBankCode = preferedBankCode;
	}

	public BigDecimal getPreferedBankId() {
		return this.preferedBankId;
	}

	public void setPreferedBankId(BigDecimal preferedBankId) {
		this.preferedBankId = preferedBankId;
	}

	public String getPreferedBankName() {
		return this.preferedBankName;
	}

	public void setPreferedBankName(String preferedBankName) {
		this.preferedBankName = preferedBankName;
	}

	public BigDecimal getPrintCount() {
		return this.printCount;
	}

	public void setPrintCount(BigDecimal printCount) {
		this.printCount = printCount;
	}

	public Date getPrintDate() {
		return this.printDate;
	}

	public void setPrintDate(Date printDate) {
		this.printDate = printDate;
	}

	public String getPrintedBy() {
		return this.printedBy;
	}

	public void setPrintedBy(String printedBy) {
		this.printedBy = printedBy;
	}

	public Date getPymtDate() {
		return this.pymtDate;
	}

	public void setPymtDate(Date pymtDate) {
		this.pymtDate = pymtDate;
	}

	public String getPymtTo() {
		return this.pymtTo;
	}

	public void setPymtTo(String pymtTo) {
		this.pymtTo = pymtTo;
	}

	public String getPymtType() {
		return this.pymtType;
	}

	public void setPymtType(String pymtType) {
		this.pymtType = pymtType;
	}

	public Date getRcptUpto() {
		return this.rcptUpto;
	}

	public void setRcptUpto(Date rcptUpto) {
		this.rcptUpto = rcptUpto;
	}

	public String getReqBookId() {
		return this.reqBookId;
	}

	public void setReqBookId(String reqBookId) {
		this.reqBookId = reqBookId;
	}

	public String getReqBranchCode() {
		return this.reqBranchCode;
	}

	public void setReqBranchCode(String reqBranchCode) {
		this.reqBranchCode = reqBranchCode;
	}

	public Date getReqDate() {
		return this.reqDate;
	}

	public void setReqDate(Date reqDate) {
		this.reqDate = reqDate;
	}

	public String getReqDocTypeAbbr() {
		return this.reqDocTypeAbbr;
	}

	public void setReqDocTypeAbbr(String reqDocTypeAbbr) {
		this.reqDocTypeAbbr = reqDocTypeAbbr;
	}

	public BigDecimal getReqNo() {
		return this.reqNo;
	}

	public void setReqNo(BigDecimal reqNo) {
		this.reqNo = reqNo;
	}

	public String getReqStatus() {
		return this.reqStatus;
	}

	public void setReqStatus(String reqStatus) {
		this.reqStatus = reqStatus;
	}

	public BigDecimal getReqTxnAmt() {
		return this.reqTxnAmt;
	}

	public void setReqTxnAmt(BigDecimal reqTxnAmt) {
		this.reqTxnAmt = reqTxnAmt;
	}

	public String getSec206abApplInd() {
		return this.sec206abApplInd;
	}

	public void setSec206abApplInd(String sec206abApplInd) {
		this.sec206abApplInd = sec206abApplInd;
	}

	public BigDecimal getSec206abExempRate() {
		return this.sec206abExempRate;
	}

	public void setSec206abExempRate(BigDecimal sec206abExempRate) {
		this.sec206abExempRate = sec206abExempRate;
	}

	public BigDecimal getSec206abRate() {
		return this.sec206abRate;
	}

	public void setSec206abRate(BigDecimal sec206abRate) {
		this.sec206abRate = sec206abRate;
	}

	public BigDecimal getServiceTaxAmount() {
		return this.serviceTaxAmount;
	}

	public void setServiceTaxAmount(BigDecimal serviceTaxAmount) {
		this.serviceTaxAmount = serviceTaxAmount;
	}

	public String getSfGstn() {
		return this.sfGstn;
	}

	public void setSfGstn(String sfGstn) {
		this.sfGstn = sfGstn;
	}

	public String getSpInvoiceNo() {
		return this.spInvoiceNo;
	}

	public void setSpInvoiceNo(String spInvoiceNo) {
		this.spInvoiceNo = spInvoiceNo;
	}

	public Date getStartTime() {
		return this.startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public String getVoucherBookId() {
		return this.voucherBookId;
	}

	public void setVoucherBookId(String voucherBookId) {
		this.voucherBookId = voucherBookId;
	}

	public String getVoucherBranchCode() {
		return this.voucherBranchCode;
	}

	public void setVoucherBranchCode(String voucherBranchCode) {
		this.voucherBranchCode = voucherBranchCode;
	}

	public Date getVoucherDate() {
		return this.voucherDate;
	}

	public void setVoucherDate(Date voucherDate) {
		this.voucherDate = voucherDate;
	}

	public BigDecimal getVoucherLedgerHdrId() {
		return this.voucherLedgerHdrId;
	}

	public void setVoucherLedgerHdrId(BigDecimal voucherLedgerHdrId) {
		this.voucherLedgerHdrId = voucherLedgerHdrId;
	}

	public BigDecimal getVoucherNo() {
		return this.voucherNo;
	}

	public void setVoucherNo(BigDecimal voucherNo) {
		this.voucherNo = voucherNo;
	}

	public List<PsTbComPymtReqDtl> getPsTbComPymtReqDtls() {
		return this.psTbComPymtReqDtls;
	}

	public void setPsTbComPymtReqDtls(List<PsTbComPymtReqDtl> psTbComPymtReqDtls) {
		this.psTbComPymtReqDtls = psTbComPymtReqDtls;
	}

	public PsTbComPymtReqDtl addPsTbComPymtReqDtl(PsTbComPymtReqDtl psTbComPymtReqDtl) {
		getPsTbComPymtReqDtls().add(psTbComPymtReqDtl);
		psTbComPymtReqDtl.setPsTbComPymtReqHdr(this);

		return psTbComPymtReqDtl;
	}

	public PsTbComPymtReqDtl removePsTbComPymtReqDtl(PsTbComPymtReqDtl psTbComPymtReqDtl) {
		getPsTbComPymtReqDtls().remove(psTbComPymtReqDtl);
		psTbComPymtReqDtl.setPsTbComPymtReqHdr(null);

		return psTbComPymtReqDtl;
	}

}