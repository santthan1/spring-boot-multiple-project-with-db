package in.sf.wcl.entity;

import java.io.Serializable;
import jakarta.persistence.*;

/**
 * The primary key class for the PS_TB_LN_CONTRACT_DEFN database table.
 * 
 */
@Embeddable
public class PsTbLnContractDefnPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="CONTRACT_ID")
	private long contractId;

	@Column(name="BU_ACTIVITY_CODE")
	private String buActivityCode;

	public PsTbLnContractDefnPK() {
	}
	public long getContractId() {
		return this.contractId;
	}
	public void setContractId(long contractId) {
		this.contractId = contractId;
	}
	public String getBuActivityCode() {
		return this.buActivityCode;
	}
	public void setBuActivityCode(String buActivityCode) {
		this.buActivityCode = buActivityCode;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof PsTbLnContractDefnPK)) {
			return false;
		}
		PsTbLnContractDefnPK castOther = (PsTbLnContractDefnPK)other;
		return 
			(this.contractId == castOther.contractId)
			&& this.buActivityCode.equals(castOther.buActivityCode);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) (this.contractId ^ (this.contractId >>> 32)));
		hash = hash * prime + this.buActivityCode.hashCode();
		
		return hash;
	}
}