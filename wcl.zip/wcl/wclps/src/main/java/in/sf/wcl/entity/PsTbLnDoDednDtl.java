package in.sf.wcl.entity;

import java.io.Serializable;
import jakarta.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the PS_TB_LN_DO_DEDN_DTLS database table.
 * 
 */
@Entity
@Table(name="PS_TB_LN_DO_DEDN_DTLS")
@NamedQuery(name="PsTbLnDoDednDtl.findAll", query="SELECT p FROM PsTbLnDoDednDtl p")
public class PsTbLnDoDednDtl implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="COMPANY_CODE")
	private String companyCode;

	@Column(name="DEDN_DTLS_RECORD_ID")
	private BigDecimal dednDtlsRecordId;

	@Column(name="DO_BOOK_ID")
	private String doBookId;

	@Column(name="DO_BRANCH_CODE")
	private String doBranchCode;

	@Column(name="DO_DOC_NO")
	private BigDecimal doDocNo;

	@Column(name="DO_RECORD_ID")
	private BigDecimal doRecordId;

	@Column(name="SOURCE_COMPONENT_IND")
	private String sourceComponentInd;

	public PsTbLnDoDednDtl() {
	}

	public String getCompanyCode() {
		return this.companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public BigDecimal getDednDtlsRecordId() {
		return this.dednDtlsRecordId;
	}

	public void setDednDtlsRecordId(BigDecimal dednDtlsRecordId) {
		this.dednDtlsRecordId = dednDtlsRecordId;
	}

	public String getDoBookId() {
		return this.doBookId;
	}

	public void setDoBookId(String doBookId) {
		this.doBookId = doBookId;
	}

	public String getDoBranchCode() {
		return this.doBranchCode;
	}

	public void setDoBranchCode(String doBranchCode) {
		this.doBranchCode = doBranchCode;
	}

	public BigDecimal getDoDocNo() {
		return this.doDocNo;
	}

	public void setDoDocNo(BigDecimal doDocNo) {
		this.doDocNo = doDocNo;
	}

	public BigDecimal getDoRecordId() {
		return this.doRecordId;
	}

	public void setDoRecordId(BigDecimal doRecordId) {
		this.doRecordId = doRecordId;
	}

	public String getSourceComponentInd() {
		return this.sourceComponentInd;
	}

	public void setSourceComponentInd(String sourceComponentInd) {
		this.sourceComponentInd = sourceComponentInd;
	}

}