package in.sf.wcl.entity;

import java.io.Serializable;
import jakarta.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the PS_TB_LN_DO_ADJ_DTLS database table.
 * 
 */
@Entity
@Table(name="PS_TB_LN_DO_ADJ_DTLS")
@NamedQuery(name="PsTbLnDoAdjDtl.findAll", query="SELECT p FROM PsTbLnDoAdjDtl p")
public class PsTbLnDoAdjDtl implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="DO_ADJ_RECORD_ID")
	private long doAdjRecordId;

	@Column(name="ADJ_AMOUNT")
	private BigDecimal adjAmount;

	@Column(name="ADJ_CATEGORY")
	private String adjCategory;

	@Column(name="ADJ_DEALER")
	private String adjDealer;

	@Column(name="AUDIT_LOG")
	private Object auditLog;

	@Column(name="COMPANY_CODE")
	private String companyCode;

	@Column(name="TA_SCHEME_CODE")
	private String taSchemeCode;

	//bi-directional many-to-one association to PsTbLnDoDtl
	@ManyToOne
	@JoinColumn(name="DO_RECORD_ID")
	private PsTbLnDoDtl psTbLnDoDtl;

	public PsTbLnDoAdjDtl() {
	}

	public long getDoAdjRecordId() {
		return this.doAdjRecordId;
	}

	public void setDoAdjRecordId(long doAdjRecordId) {
		this.doAdjRecordId = doAdjRecordId;
	}

	public BigDecimal getAdjAmount() {
		return this.adjAmount;
	}

	public void setAdjAmount(BigDecimal adjAmount) {
		this.adjAmount = adjAmount;
	}

	public String getAdjCategory() {
		return this.adjCategory;
	}

	public void setAdjCategory(String adjCategory) {
		this.adjCategory = adjCategory;
	}

	public String getAdjDealer() {
		return this.adjDealer;
	}

	public void setAdjDealer(String adjDealer) {
		this.adjDealer = adjDealer;
	}

	public Object getAuditLog() {
		return this.auditLog;
	}

	public void setAuditLog(Object auditLog) {
		this.auditLog = auditLog;
	}

	public String getCompanyCode() {
		return this.companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getTaSchemeCode() {
		return this.taSchemeCode;
	}

	public void setTaSchemeCode(String taSchemeCode) {
		this.taSchemeCode = taSchemeCode;
	}

	public PsTbLnDoDtl getPsTbLnDoDtl() {
		return this.psTbLnDoDtl;
	}

	public void setPsTbLnDoDtl(PsTbLnDoDtl psTbLnDoDtl) {
		this.psTbLnDoDtl = psTbLnDoDtl;
	}

}