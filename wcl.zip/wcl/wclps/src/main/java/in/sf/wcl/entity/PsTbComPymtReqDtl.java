package in.sf.wcl.entity;

import java.io.Serializable;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the PS_TB_COM_PYMT_REQ_DTLS database table.
 * 
 */
@Entity
@Table(name="PS_TB_COM_PYMT_REQ_DTLS")
@NamedQuery(name="PsTbComPymtReqDtl.findAll", query="SELECT p FROM PsTbComPymtReqDtl p")
public class PsTbComPymtReqDtl implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="PYMT_REQ_DTLS_ID")
	private long pymtReqDtlsId;

	@Column(name="ASSET_SLNO")
	private BigDecimal assetSlno;

	@Column(name="COMPANY_CODE")
	private String companyCode;

	@Column(name="COVER_NOTE_NO")
	private BigDecimal coverNoteNo;

	@Column(name="DEDN_AMT")
	private BigDecimal dednAmt;

	@Column(name="DIMENSION_NAME")
	private String dimensionName;

	@Column(name="DIMENSION_VALUE_CODE")
	private String dimensionValueCode;

	@Column(name="ENTITY_CODE")
	private String entityCode;

	@Column(name="ENTITY_TYPE")
	private String entityType;

	@Column(name="EQUIPMENT_NO")
	private BigDecimal equipmentNo;

	@Column(name="GST_WH_AMOUNT")
	private BigDecimal gstWhAmount;

	@Column(name="GST_WH_NET_AMOUNT")
	private BigDecimal gstWhNetAmount;

	@Column(name="INSUR_PYMT_TYPE")
	private String insurPymtType;

	@Column(name="POLICY_YEAR")
	private String policyYear;

	@Column(name="PR_TYPE")
	private BigDecimal prType;

	@Column(name="PYMT_38_CANCEL_IND")
	private String pymt38CancelInd;

	@Column(name="PYMT_TYPE_IND")
	private String pymtTypeInd;

	@Column(name="REF_BOOK_ID")
	private String refBookId;

	@Column(name="REF_BRANCH_CODE")
	private String refBranchCode;

	@Temporal(TemporalType.DATE)
	@Column(name="REF_DATE")
	private Date refDate;

	@Column(name="REF_NUMBER")
	private BigDecimal refNumber;

	private String remarks;

	@Column(name="REQ_TXN_AMT")
	private BigDecimal reqTxnAmt;

	@Column(name="TDS_AMT")
	private BigDecimal tdsAmt;

	@Column(name="TDS_CODE")
	private String tdsCode;

	@Column(name="TDS_IND")
	private String tdsInd;

	@Column(name="TDS_SECTION_CODE")
	private String tdsSectionCode;

	@Column(name="TDS_TXN_TYPE")
	private BigDecimal tdsTxnType;

	@Column(name="TDS194Q_APPL_IND")
	private String tds194qApplInd;

	@Column(name="TDS194Q_TXN_AMT")
	private BigDecimal tds194qTxnAmt;

	@Temporal(TemporalType.DATE)
	@Column(name="TXN_DATE")
	private Date txnDate;

	@Column(name="TXN_TYPE")
	private BigDecimal txnType;

	//bi-directional many-to-one association to PsTbComPymtReqHdr
	@ManyToOne
	@JoinColumn(name="PYMT_REQ_HDR_ID")
	private PsTbComPymtReqHdr psTbComPymtReqHdr;

	public PsTbComPymtReqDtl() {
	}

	public long getPymtReqDtlsId() {
		return this.pymtReqDtlsId;
	}

	public void setPymtReqDtlsId(long pymtReqDtlsId) {
		this.pymtReqDtlsId = pymtReqDtlsId;
	}

	public BigDecimal getAssetSlno() {
		return this.assetSlno;
	}

	public void setAssetSlno(BigDecimal assetSlno) {
		this.assetSlno = assetSlno;
	}

	public String getCompanyCode() {
		return this.companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public BigDecimal getCoverNoteNo() {
		return this.coverNoteNo;
	}

	public void setCoverNoteNo(BigDecimal coverNoteNo) {
		this.coverNoteNo = coverNoteNo;
	}

	public BigDecimal getDednAmt() {
		return this.dednAmt;
	}

	public void setDednAmt(BigDecimal dednAmt) {
		this.dednAmt = dednAmt;
	}

	public String getDimensionName() {
		return this.dimensionName;
	}

	public void setDimensionName(String dimensionName) {
		this.dimensionName = dimensionName;
	}

	public String getDimensionValueCode() {
		return this.dimensionValueCode;
	}

	public void setDimensionValueCode(String dimensionValueCode) {
		this.dimensionValueCode = dimensionValueCode;
	}

	public String getEntityCode() {
		return this.entityCode;
	}

	public void setEntityCode(String entityCode) {
		this.entityCode = entityCode;
	}

	public String getEntityType() {
		return this.entityType;
	}

	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}

	public BigDecimal getEquipmentNo() {
		return this.equipmentNo;
	}

	public void setEquipmentNo(BigDecimal equipmentNo) {
		this.equipmentNo = equipmentNo;
	}

	public BigDecimal getGstWhAmount() {
		return this.gstWhAmount;
	}

	public void setGstWhAmount(BigDecimal gstWhAmount) {
		this.gstWhAmount = gstWhAmount;
	}

	public BigDecimal getGstWhNetAmount() {
		return this.gstWhNetAmount;
	}

	public void setGstWhNetAmount(BigDecimal gstWhNetAmount) {
		this.gstWhNetAmount = gstWhNetAmount;
	}

	public String getInsurPymtType() {
		return this.insurPymtType;
	}

	public void setInsurPymtType(String insurPymtType) {
		this.insurPymtType = insurPymtType;
	}

	public String getPolicyYear() {
		return this.policyYear;
	}

	public void setPolicyYear(String policyYear) {
		this.policyYear = policyYear;
	}

	public BigDecimal getPrType() {
		return this.prType;
	}

	public void setPrType(BigDecimal prType) {
		this.prType = prType;
	}

	public String getPymt38CancelInd() {
		return this.pymt38CancelInd;
	}

	public void setPymt38CancelInd(String pymt38CancelInd) {
		this.pymt38CancelInd = pymt38CancelInd;
	}

	public String getPymtTypeInd() {
		return this.pymtTypeInd;
	}

	public void setPymtTypeInd(String pymtTypeInd) {
		this.pymtTypeInd = pymtTypeInd;
	}

	public String getRefBookId() {
		return this.refBookId;
	}

	public void setRefBookId(String refBookId) {
		this.refBookId = refBookId;
	}

	public String getRefBranchCode() {
		return this.refBranchCode;
	}

	public void setRefBranchCode(String refBranchCode) {
		this.refBranchCode = refBranchCode;
	}

	public Date getRefDate() {
		return this.refDate;
	}

	public void setRefDate(Date refDate) {
		this.refDate = refDate;
	}

	public BigDecimal getRefNumber() {
		return this.refNumber;
	}

	public void setRefNumber(BigDecimal refNumber) {
		this.refNumber = refNumber;
	}

	public String getRemarks() {
		return this.remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public BigDecimal getReqTxnAmt() {
		return this.reqTxnAmt;
	}

	public void setReqTxnAmt(BigDecimal reqTxnAmt) {
		this.reqTxnAmt = reqTxnAmt;
	}

	public BigDecimal getTdsAmt() {
		return this.tdsAmt;
	}

	public void setTdsAmt(BigDecimal tdsAmt) {
		this.tdsAmt = tdsAmt;
	}

	public String getTdsCode() {
		return this.tdsCode;
	}

	public void setTdsCode(String tdsCode) {
		this.tdsCode = tdsCode;
	}

	public String getTdsInd() {
		return this.tdsInd;
	}

	public void setTdsInd(String tdsInd) {
		this.tdsInd = tdsInd;
	}

	public String getTdsSectionCode() {
		return this.tdsSectionCode;
	}

	public void setTdsSectionCode(String tdsSectionCode) {
		this.tdsSectionCode = tdsSectionCode;
	}

	public BigDecimal getTdsTxnType() {
		return this.tdsTxnType;
	}

	public void setTdsTxnType(BigDecimal tdsTxnType) {
		this.tdsTxnType = tdsTxnType;
	}

	public String getTds194qApplInd() {
		return this.tds194qApplInd;
	}

	public void setTds194qApplInd(String tds194qApplInd) {
		this.tds194qApplInd = tds194qApplInd;
	}

	public BigDecimal getTds194qTxnAmt() {
		return this.tds194qTxnAmt;
	}

	public void setTds194qTxnAmt(BigDecimal tds194qTxnAmt) {
		this.tds194qTxnAmt = tds194qTxnAmt;
	}

	public Date getTxnDate() {
		return this.txnDate;
	}

	public void setTxnDate(Date txnDate) {
		this.txnDate = txnDate;
	}

	public BigDecimal getTxnType() {
		return this.txnType;
	}

	public void setTxnType(BigDecimal txnType) {
		this.txnType = txnType;
	}

	public PsTbComPymtReqHdr getPsTbComPymtReqHdr() {
		return this.psTbComPymtReqHdr;
	}

	public void setPsTbComPymtReqHdr(PsTbComPymtReqHdr psTbComPymtReqHdr) {
		this.psTbComPymtReqHdr = psTbComPymtReqHdr;
	}

}