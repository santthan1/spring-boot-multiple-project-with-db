package in.sf.wcl.entity;

import java.io.Serializable;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the PS_TB_SME_PBF_CONTRACT_DTLS database table.
 * 
 */
@Entity
@Table(name="PS_TB_SME_PBF_CONTRACT_DTLS")
@NamedQuery(name="PsTbSmePbfContractDtl.findAll", query="SELECT p FROM PsTbSmePbfContractDtl p")
public class PsTbSmePbfContractDtl implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="AUDIT_LOG")
	private Object auditLog;

	@Column(name="COMPANY_CODE")
	private String companyCode;

	@Column(name="CONTRACT_NO")
	private String contractNo;

	@Temporal(TemporalType.DATE)
	@Column(name="INVOICE_DATE")
	private Date invoiceDate;

	@Column(name="INVOICE_NUMBER")
	private String invoiceNumber;

	@Column(name="INVOICE_VALUE")
	private BigDecimal invoiceValue;

	@Column(name="RECORD_ID")
	private BigDecimal recordId;

	private String remarks;

	@Column(name="SL_NO")
	private BigDecimal slNo;

	public PsTbSmePbfContractDtl() {
	}

	public Object getAuditLog() {
		return this.auditLog;
	}

	public void setAuditLog(Object auditLog) {
		this.auditLog = auditLog;
	}

	public String getCompanyCode() {
		return this.companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getContractNo() {
		return this.contractNo;
	}

	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}

	public Date getInvoiceDate() {
		return this.invoiceDate;
	}

	public void setInvoiceDate(Date invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public String getInvoiceNumber() {
		return this.invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public BigDecimal getInvoiceValue() {
		return this.invoiceValue;
	}

	public void setInvoiceValue(BigDecimal invoiceValue) {
		this.invoiceValue = invoiceValue;
	}

	public BigDecimal getRecordId() {
		return this.recordId;
	}

	public void setRecordId(BigDecimal recordId) {
		this.recordId = recordId;
	}

	public String getRemarks() {
		return this.remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public BigDecimal getSlNo() {
		return this.slNo;
	}

	public void setSlNo(BigDecimal slNo) {
		this.slNo = slNo;
	}

}