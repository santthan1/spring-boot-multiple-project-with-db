package in.sf.wcl.entity;

import javax.persistence.Entity;

@Entity
public class sample {

    private Long id;
    private String name;
    private Long age;
    private String remarks;

    public sample() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getAge() {
        return age;
    }

    public void setAge(Long age) {
        this.age = age;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public sample(Long id, String name, Long age, String remarks) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.remarks = remarks;
    }



}
