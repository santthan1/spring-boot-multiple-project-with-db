package in.sf.wcl.entity;

import java.io.Serializable;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the PS_TB_LN_CONTRACT_FINANCE_DTLS database table.
 * 
 */
@Entity
@Table(name="PS_TB_LN_CONTRACT_FINANCE_DTLS")
@NamedQuery(name="PsTbLnContractFinanceDtl.findAll", query="SELECT p FROM PsTbLnContractFinanceDtl p")
public class PsTbLnContractFinanceDtl implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="ACCOUNTING_IRR")
	private BigDecimal accountingIrr;

	@Column(name="AFC_RATE")
	private BigDecimal afcRate;

	@Column(name="ASSET_STRUCT_ID")
	private BigDecimal assetStructId;

	@Column(name="ASSET_TYPE_ID")
	private BigDecimal assetTypeId;

	@Column(name="AUDIT_LOG")
	private Object auditLog;

	@Column(name="BASE_AMOUNT_FINANCE")
	private BigDecimal baseAmountFinance;

	@Column(name="BODY_CHARGES")
	private BigDecimal bodyCharges;

	@Column(name="COMPANY_CODE")
	private String companyCode;

	@Column(name="COMPANY_IRR")
	private BigDecimal companyIrr;

	@Column(name="CONTRACT_NO")
	private String contractNo;

	@Column(name="CONTRACT_SCHEME_CODE")
	private String contractSchemeCode;

	@Column(name="CREDIT_DAYS")
	private BigDecimal creditDays;

	@Column(name="CURR_AMOUNT_FINANCE")
	private BigDecimal currAmountFinance;

	@Column(name="CURR_AMOUNT_REPAY")
	private BigDecimal currAmountRepay;

	@Column(name="CURR_FINANCE_CHGS")
	private BigDecimal currFinanceChgs;

	@Column(name="DEALER_CODE")
	private String dealerCode;

	@Column(name="DEFERRED_PYMT_IND")
	private String deferredPymtInd;

	@Column(name="DELIVERY_DEALER")
	private String deliveryDealer;

	@Column(name="DISBURSEMENT_TYPE")
	private String disbursementType;

	@Column(name="DMA_PAYOUT_APPL")
	private String dmaPayoutAppl;

	@Column(name="DUES_IN_ADVANCE")
	private BigDecimal duesInAdvance;

	@Column(name="EFFECTIVE_IRR")
	private BigDecimal effectiveIrr;

	@Column(name="EIR_CURR_AMOUNT_FINANCE")
	private BigDecimal eirCurrAmountFinance;

	@Column(name="EIR_CURR_FINANCE_CHGS")
	private BigDecimal eirCurrFinanceChgs;

	@Column(name="EIR_ORG_AMOUNT_FINANCE")
	private BigDecimal eirOrgAmountFinance;

	@Column(name="EIR_ORG_FINANCE_CHGS")
	private BigDecimal eirOrgFinanceChgs;

	@Temporal(TemporalType.DATE)
	@Column(name="FIRST_INSTL_DATE")
	private Date firstInstlDate;

	@Column(name="FIXED_BILLING_DAY")
	private BigDecimal fixedBillingDay;

	@Column(name="FLAT_RATE")
	private BigDecimal flatRate;

	@Column(name="FLOAT_RATE_IND")
	private String floatRateInd;

	@Column(name="HIRE_PERIOD")
	private BigDecimal hirePeriod;

	@Column(name="HOLIDAY_MONTHS")
	private BigDecimal holidayMonths;

	@Column(name="IMPL_AMOUNT_FINANCE")
	private BigDecimal implAmountFinance;

	private BigDecimal installments;

	@Column(name="INSUR_BRANCH_CODE")
	private BigDecimal insurBranchCode;

	@Column(name="INSUR_COMPANY_CODE")
	private BigDecimal insurCompanyCode;

	@Column(name="INSURANCE_COMPANY_REASON")
	private String insuranceCompanyReason;

	@Column(name="INSURANCE_TYPE")
	private String insuranceType;

	@Column(name="INTEREST_PERIOD")
	private BigDecimal interestPeriod;

	@Column(name="INTEREST_RATE")
	private BigDecimal interestRate;

	@Temporal(TemporalType.DATE)
	@Column(name="LOAN_END_DATE")
	private Date loanEndDate;

	private BigDecimal model;

	@Column(name="ORG_AMOUNT_FINANCE")
	private BigDecimal orgAmountFinance;

	@Column(name="ORG_AMOUNT_REPAY")
	private BigDecimal orgAmountRepay;

	@Column(name="ORG_FINANCE_CHGS")
	private BigDecimal orgFinanceChgs;

	@Column(name="PPR_AMT")
	private BigDecimal pprAmt;

	@Column(name="PPR_RATE")
	private BigDecimal pprRate;

	@Column(name="PYMT_ADJ_IND")
	private String pymtAdjInd;

	@Column(name="REPAY_FREQ")
	private String repayFreq;

	@Column(name="REPAY_MODE")
	private String repayMode;

	@Column(name="SANCTIONED_LIMIT")
	private BigDecimal sanctionedLimit;

	@Column(name="SCP_AMOUNT_FINANCE")
	private BigDecimal scpAmountFinance;

	@Column(name="SELLER_CODE")
	private String sellerCode;

	@Column(name="SHORT_TERM_RATE")
	private BigDecimal shortTermRate;

	@Column(name="SUBVENTION_IRR")
	private BigDecimal subventionIrr;

	@Column(name="TCS_AMOUNT")
	private BigDecimal tcsAmount;

	@Column(name="TRACTOR_INSUR_AMOUNT")
	private BigDecimal tractorInsurAmount;

	@Column(name="UNITS_COUNT")
	private BigDecimal unitsCount;

	@Column(name="UTILIZED_AMOUNT")
	private BigDecimal utilizedAmount;

	@Column(name="VAR_NET_EXC_COMM_IRR")
	private BigDecimal varNetExcCommIrr;

	@Column(name="VAR_NET_IRR")
	private BigDecimal varNetIrr;

	public PsTbLnContractFinanceDtl() {
	}

	public BigDecimal getAccountingIrr() {
		return this.accountingIrr;
	}

	public void setAccountingIrr(BigDecimal accountingIrr) {
		this.accountingIrr = accountingIrr;
	}

	public BigDecimal getAfcRate() {
		return this.afcRate;
	}

	public void setAfcRate(BigDecimal afcRate) {
		this.afcRate = afcRate;
	}

	public BigDecimal getAssetStructId() {
		return this.assetStructId;
	}

	public void setAssetStructId(BigDecimal assetStructId) {
		this.assetStructId = assetStructId;
	}

	public BigDecimal getAssetTypeId() {
		return this.assetTypeId;
	}

	public void setAssetTypeId(BigDecimal assetTypeId) {
		this.assetTypeId = assetTypeId;
	}

	public Object getAuditLog() {
		return this.auditLog;
	}

	public void setAuditLog(Object auditLog) {
		this.auditLog = auditLog;
	}

	public BigDecimal getBaseAmountFinance() {
		return this.baseAmountFinance;
	}

	public void setBaseAmountFinance(BigDecimal baseAmountFinance) {
		this.baseAmountFinance = baseAmountFinance;
	}

	public BigDecimal getBodyCharges() {
		return this.bodyCharges;
	}

	public void setBodyCharges(BigDecimal bodyCharges) {
		this.bodyCharges = bodyCharges;
	}

	public String getCompanyCode() {
		return this.companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public BigDecimal getCompanyIrr() {
		return this.companyIrr;
	}

	public void setCompanyIrr(BigDecimal companyIrr) {
		this.companyIrr = companyIrr;
	}

	public String getContractNo() {
		return this.contractNo;
	}

	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}

	public String getContractSchemeCode() {
		return this.contractSchemeCode;
	}

	public void setContractSchemeCode(String contractSchemeCode) {
		this.contractSchemeCode = contractSchemeCode;
	}

	public BigDecimal getCreditDays() {
		return this.creditDays;
	}

	public void setCreditDays(BigDecimal creditDays) {
		this.creditDays = creditDays;
	}

	public BigDecimal getCurrAmountFinance() {
		return this.currAmountFinance;
	}

	public void setCurrAmountFinance(BigDecimal currAmountFinance) {
		this.currAmountFinance = currAmountFinance;
	}

	public BigDecimal getCurrAmountRepay() {
		return this.currAmountRepay;
	}

	public void setCurrAmountRepay(BigDecimal currAmountRepay) {
		this.currAmountRepay = currAmountRepay;
	}

	public BigDecimal getCurrFinanceChgs() {
		return this.currFinanceChgs;
	}

	public void setCurrFinanceChgs(BigDecimal currFinanceChgs) {
		this.currFinanceChgs = currFinanceChgs;
	}

	public String getDealerCode() {
		return this.dealerCode;
	}

	public void setDealerCode(String dealerCode) {
		this.dealerCode = dealerCode;
	}

	public String getDeferredPymtInd() {
		return this.deferredPymtInd;
	}

	public void setDeferredPymtInd(String deferredPymtInd) {
		this.deferredPymtInd = deferredPymtInd;
	}

	public String getDeliveryDealer() {
		return this.deliveryDealer;
	}

	public void setDeliveryDealer(String deliveryDealer) {
		this.deliveryDealer = deliveryDealer;
	}

	public String getDisbursementType() {
		return this.disbursementType;
	}

	public void setDisbursementType(String disbursementType) {
		this.disbursementType = disbursementType;
	}

	public String getDmaPayoutAppl() {
		return this.dmaPayoutAppl;
	}

	public void setDmaPayoutAppl(String dmaPayoutAppl) {
		this.dmaPayoutAppl = dmaPayoutAppl;
	}

	public BigDecimal getDuesInAdvance() {
		return this.duesInAdvance;
	}

	public void setDuesInAdvance(BigDecimal duesInAdvance) {
		this.duesInAdvance = duesInAdvance;
	}

	public BigDecimal getEffectiveIrr() {
		return this.effectiveIrr;
	}

	public void setEffectiveIrr(BigDecimal effectiveIrr) {
		this.effectiveIrr = effectiveIrr;
	}

	public BigDecimal getEirCurrAmountFinance() {
		return this.eirCurrAmountFinance;
	}

	public void setEirCurrAmountFinance(BigDecimal eirCurrAmountFinance) {
		this.eirCurrAmountFinance = eirCurrAmountFinance;
	}

	public BigDecimal getEirCurrFinanceChgs() {
		return this.eirCurrFinanceChgs;
	}

	public void setEirCurrFinanceChgs(BigDecimal eirCurrFinanceChgs) {
		this.eirCurrFinanceChgs = eirCurrFinanceChgs;
	}

	public BigDecimal getEirOrgAmountFinance() {
		return this.eirOrgAmountFinance;
	}

	public void setEirOrgAmountFinance(BigDecimal eirOrgAmountFinance) {
		this.eirOrgAmountFinance = eirOrgAmountFinance;
	}

	public BigDecimal getEirOrgFinanceChgs() {
		return this.eirOrgFinanceChgs;
	}

	public void setEirOrgFinanceChgs(BigDecimal eirOrgFinanceChgs) {
		this.eirOrgFinanceChgs = eirOrgFinanceChgs;
	}

	public Date getFirstInstlDate() {
		return this.firstInstlDate;
	}

	public void setFirstInstlDate(Date firstInstlDate) {
		this.firstInstlDate = firstInstlDate;
	}

	public BigDecimal getFixedBillingDay() {
		return this.fixedBillingDay;
	}

	public void setFixedBillingDay(BigDecimal fixedBillingDay) {
		this.fixedBillingDay = fixedBillingDay;
	}

	public BigDecimal getFlatRate() {
		return this.flatRate;
	}

	public void setFlatRate(BigDecimal flatRate) {
		this.flatRate = flatRate;
	}

	public String getFloatRateInd() {
		return this.floatRateInd;
	}

	public void setFloatRateInd(String floatRateInd) {
		this.floatRateInd = floatRateInd;
	}

	public BigDecimal getHirePeriod() {
		return this.hirePeriod;
	}

	public void setHirePeriod(BigDecimal hirePeriod) {
		this.hirePeriod = hirePeriod;
	}

	public BigDecimal getHolidayMonths() {
		return this.holidayMonths;
	}

	public void setHolidayMonths(BigDecimal holidayMonths) {
		this.holidayMonths = holidayMonths;
	}

	public BigDecimal getImplAmountFinance() {
		return this.implAmountFinance;
	}

	public void setImplAmountFinance(BigDecimal implAmountFinance) {
		this.implAmountFinance = implAmountFinance;
	}

	public BigDecimal getInstallments() {
		return this.installments;
	}

	public void setInstallments(BigDecimal installments) {
		this.installments = installments;
	}

	public BigDecimal getInsurBranchCode() {
		return this.insurBranchCode;
	}

	public void setInsurBranchCode(BigDecimal insurBranchCode) {
		this.insurBranchCode = insurBranchCode;
	}

	public BigDecimal getInsurCompanyCode() {
		return this.insurCompanyCode;
	}

	public void setInsurCompanyCode(BigDecimal insurCompanyCode) {
		this.insurCompanyCode = insurCompanyCode;
	}

	public String getInsuranceCompanyReason() {
		return this.insuranceCompanyReason;
	}

	public void setInsuranceCompanyReason(String insuranceCompanyReason) {
		this.insuranceCompanyReason = insuranceCompanyReason;
	}

	public String getInsuranceType() {
		return this.insuranceType;
	}

	public void setInsuranceType(String insuranceType) {
		this.insuranceType = insuranceType;
	}

	public BigDecimal getInterestPeriod() {
		return this.interestPeriod;
	}

	public void setInterestPeriod(BigDecimal interestPeriod) {
		this.interestPeriod = interestPeriod;
	}

	public BigDecimal getInterestRate() {
		return this.interestRate;
	}

	public void setInterestRate(BigDecimal interestRate) {
		this.interestRate = interestRate;
	}

	public Date getLoanEndDate() {
		return this.loanEndDate;
	}

	public void setLoanEndDate(Date loanEndDate) {
		this.loanEndDate = loanEndDate;
	}

	public BigDecimal getModel() {
		return this.model;
	}

	public void setModel(BigDecimal model) {
		this.model = model;
	}

	public BigDecimal getOrgAmountFinance() {
		return this.orgAmountFinance;
	}

	public void setOrgAmountFinance(BigDecimal orgAmountFinance) {
		this.orgAmountFinance = orgAmountFinance;
	}

	public BigDecimal getOrgAmountRepay() {
		return this.orgAmountRepay;
	}

	public void setOrgAmountRepay(BigDecimal orgAmountRepay) {
		this.orgAmountRepay = orgAmountRepay;
	}

	public BigDecimal getOrgFinanceChgs() {
		return this.orgFinanceChgs;
	}

	public void setOrgFinanceChgs(BigDecimal orgFinanceChgs) {
		this.orgFinanceChgs = orgFinanceChgs;
	}

	public BigDecimal getPprAmt() {
		return this.pprAmt;
	}

	public void setPprAmt(BigDecimal pprAmt) {
		this.pprAmt = pprAmt;
	}

	public BigDecimal getPprRate() {
		return this.pprRate;
	}

	public void setPprRate(BigDecimal pprRate) {
		this.pprRate = pprRate;
	}

	public String getPymtAdjInd() {
		return this.pymtAdjInd;
	}

	public void setPymtAdjInd(String pymtAdjInd) {
		this.pymtAdjInd = pymtAdjInd;
	}

	public String getRepayFreq() {
		return this.repayFreq;
	}

	public void setRepayFreq(String repayFreq) {
		this.repayFreq = repayFreq;
	}

	public String getRepayMode() {
		return this.repayMode;
	}

	public void setRepayMode(String repayMode) {
		this.repayMode = repayMode;
	}

	public BigDecimal getSanctionedLimit() {
		return this.sanctionedLimit;
	}

	public void setSanctionedLimit(BigDecimal sanctionedLimit) {
		this.sanctionedLimit = sanctionedLimit;
	}

	public BigDecimal getScpAmountFinance() {
		return this.scpAmountFinance;
	}

	public void setScpAmountFinance(BigDecimal scpAmountFinance) {
		this.scpAmountFinance = scpAmountFinance;
	}

	public String getSellerCode() {
		return this.sellerCode;
	}

	public void setSellerCode(String sellerCode) {
		this.sellerCode = sellerCode;
	}

	public BigDecimal getShortTermRate() {
		return this.shortTermRate;
	}

	public void setShortTermRate(BigDecimal shortTermRate) {
		this.shortTermRate = shortTermRate;
	}

	public BigDecimal getSubventionIrr() {
		return this.subventionIrr;
	}

	public void setSubventionIrr(BigDecimal subventionIrr) {
		this.subventionIrr = subventionIrr;
	}

	public BigDecimal getTcsAmount() {
		return this.tcsAmount;
	}

	public void setTcsAmount(BigDecimal tcsAmount) {
		this.tcsAmount = tcsAmount;
	}

	public BigDecimal getTractorInsurAmount() {
		return this.tractorInsurAmount;
	}

	public void setTractorInsurAmount(BigDecimal tractorInsurAmount) {
		this.tractorInsurAmount = tractorInsurAmount;
	}

	public BigDecimal getUnitsCount() {
		return this.unitsCount;
	}

	public void setUnitsCount(BigDecimal unitsCount) {
		this.unitsCount = unitsCount;
	}

	public BigDecimal getUtilizedAmount() {
		return this.utilizedAmount;
	}

	public void setUtilizedAmount(BigDecimal utilizedAmount) {
		this.utilizedAmount = utilizedAmount;
	}

	public BigDecimal getVarNetExcCommIrr() {
		return this.varNetExcCommIrr;
	}

	public void setVarNetExcCommIrr(BigDecimal varNetExcCommIrr) {
		this.varNetExcCommIrr = varNetExcCommIrr;
	}

	public BigDecimal getVarNetIrr() {
		return this.varNetIrr;
	}

	public void setVarNetIrr(BigDecimal varNetIrr) {
		this.varNetIrr = varNetIrr;
	}

}