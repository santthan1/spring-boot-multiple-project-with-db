package in.sf.wcl.entity;

import java.io.Serializable;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the PS_TB_COM_PYMT_HDR database table.
 * 
 */
@Entity
@Table(name="PS_TB_COM_PYMT_HDR")
@NamedQuery(name="PsTbComPymtHdr.findAll", query="SELECT p FROM PsTbComPymtHdr p")
public class PsTbComPymtHdr implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="GL_PYMT_HDR_ID")
	private long glPymtHdrId;

	@Column(name="ACTION_TYPE_CODE")
	private String actionTypeCode;

	@Column(name="ADVICE_BOOK_ID")
	private String adviceBookId;

	@Column(name="ADVICE_BRANCH_CODE")
	private String adviceBranchCode;

	@Temporal(TemporalType.DATE)
	@Column(name="ADVICE_DATE")
	private Date adviceDate;

	@Column(name="ADVICE_HDR_ID")
	private BigDecimal adviceHdrId;

	@Column(name="ADVICE_NO")
	private BigDecimal adviceNo;

	@Column(name="ADVICE_PRINT_COUNT")
	private BigDecimal advicePrintCount;

	@Column(name="ADVICE_PRINTED_BY")
	private String advicePrintedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="ADVICE_PRINTED_DATE")
	private Date advicePrintedDate;

	@Column(name="APPLICATION_CODE")
	private String applicationCode;

	@Column(name="AUDIT_LOG")
	private Object auditLog;

	@Column(name="AUTH_CONTROL_IND")
	private String authControlInd;

	@Column(name="AUTH_DETAILS")
	private Object authDetails;

	@Temporal(TemporalType.DATE)
	@Column(name="BANK_REF_DATE")
	private Date bankRefDate;

	@Column(name="BANK_REF_NO")
	private String bankRefNo;

	@Column(name="BENEFICIARY_ACCT_NO")
	private String beneficiaryAcctNo;

	@Column(name="BENEFICIARY_ACCT_TYPE")
	private BigDecimal beneficiaryAcctType;

	@Column(name="BENEFICIARY_BANK")
	private String beneficiaryBank;

	@Column(name="BENEFICIARY_BANK_BRANCH")
	private String beneficiaryBankBranch;

	@Column(name="BENEFICIARY_BANK_BRANCH_ID")
	private BigDecimal beneficiaryBankBranchId;

	@Column(name="BENEFICIARY_BANK_ID")
	private BigDecimal beneficiaryBankId;

	@Column(name="CANCELLED_BY")
	private String cancelledBy;

	@Temporal(TemporalType.DATE)
	@Column(name="CANCELLED_DATE")
	private Date cancelledDate;

	@Column(name="CANCELLED_REMARKS")
	private String cancelledRemarks;

	@Column(name="CHQ_BOOK_STATUS")
	private String chqBookStatus;

	@Column(name="CHQ_PRINT_COUNT")
	private BigDecimal chqPrintCount;

	@Column(name="CHQ_PRINTED_BY")
	private String chqPrintedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="CHQ_PRINTED_DATE")
	private Date chqPrintedDate;

	@Column(name="COMPANY_CODE")
	private String companyCode;

	@Column(name="CONTACT_ID")
	private BigDecimal contactId;

	@Column(name="CONTACT_ROLE")
	private String contactRole;

	@Column(name="COVERING_LETTER_PRINT_COUNT")
	private BigDecimal coveringLetterPrintCount;

	@Column(name="COVERING_LETTER_PRINTED_BY")
	private String coveringLetterPrintedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="COVERING_LETTER_PRINTED_DATE")
	private Date coveringLetterPrintedDate;

	@Column(name="CR_ACTIVITY_ID")
	private BigDecimal crActivityId;

	@Column(name="CR_BRANCH_ID")
	private BigDecimal crBranchId;

	@Column(name="CR_GL_ACCT_ID")
	private BigDecimal crGlAcctId;

	@Column(name="CR_SEGMENT5_NAME")
	private String crSegment5Name;

	@Column(name="CR_SEGMENT5_VALUE_ID")
	private BigDecimal crSegment5ValueId;

	@Column(name="CR_SUBGL_TYPE")
	private String crSubglType;

	@Column(name="CR_SUBGL_VALUE_ID")
	private BigDecimal crSubglValueId;

	@Column(name="CURRENCY_CODE")
	private String currencyCode;

	@Column(name="DRAWEE_PLACE")
	private String draweePlace;

	@Temporal(TemporalType.DATE)
	@Column(name="END_TIME")
	private Date endTime;

	@Column(name="FAVORING_NAME")
	private String favoringName;

	@Column(name="FAVOURING_NAME_OPTION")
	private String favouringNameOption;

	private String ifsc;

	@Column(name="INST_BOOK_KEY_ID")
	private BigDecimal instBookKeyId;

	@Temporal(TemporalType.DATE)
	@Column(name="INST_DATE")
	private Date instDate;

	@Column(name="INST_NO")
	private BigDecimal instNo;

	@Column(name="INST_TYPE")
	private String instType;

	@Column(name="LEDGER_HDR_ID")
	private BigDecimal ledgerHdrId;

	@Column(name="MODULE_CODE")
	private String moduleCode;

	@Column(name="PYMT_OPTION")
	private String pymtOption;

	@Column(name="PYMT_REMARKS")
	private String pymtRemarks;

	@Column(name="REV_BOOK_ID")
	private String revBookId;

	@Column(name="REV_BRANCH_CODE")
	private String revBranchCode;

	@Column(name="REV_LEDGER_HDR_ID")
	private BigDecimal revLedgerHdrId;

	@Column(name="REV_VOUCHER_NO")
	private BigDecimal revVoucherNo;

	@Column(name="REVERSAL_APPROVAL_STATUS")
	private String reversalApprovalStatus;

	@Temporal(TemporalType.DATE)
	@Column(name="REVERSAL_APPROVED_DATE")
	private Date reversalApprovedDate;

	@Column(name="REVERSAL_APPROVED_USER")
	private String reversalApprovedUser;

	@Temporal(TemporalType.DATE)
	@Column(name="REVERSAL_REQUESTED_DATE")
	private Date reversalRequestedDate;

	@Column(name="REVERSAL_REQUESTED_USER")
	private String reversalRequestedUser;

	@Temporal(TemporalType.DATE)
	@Column(name="START_TIME")
	private Date startTime;

	@Column(name="VOUCHER_AMT")
	private BigDecimal voucherAmt;

	@Column(name="VOUCHER_BOOK_ID")
	private String voucherBookId;

	@Column(name="VOUCHER_BRANCH_CODE")
	private String voucherBranchCode;

	@Column(name="VOUCHER_BRANCH_ID")
	private BigDecimal voucherBranchId;

	@Temporal(TemporalType.DATE)
	@Column(name="VOUCHER_DATE")
	private Date voucherDate;

	@Column(name="VOUCHER_NO")
	private BigDecimal voucherNo;

	@Column(name="VOUCHER_PRINT_COUNT")
	private BigDecimal voucherPrintCount;

	@Column(name="VOUCHER_PRINTED_BY")
	private String voucherPrintedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="VOUCHER_PRINTED_DATE")
	private Date voucherPrintedDate;

	@Column(name="VOUCHER_STATUS")
	private String voucherStatus;

	@Column(name="VOUCHER_TYPE_ABBR")
	private String voucherTypeAbbr;

	public PsTbComPymtHdr() {
	}

	public long getGlPymtHdrId() {
		return this.glPymtHdrId;
	}

	public void setGlPymtHdrId(long glPymtHdrId) {
		this.glPymtHdrId = glPymtHdrId;
	}

	public String getActionTypeCode() {
		return this.actionTypeCode;
	}

	public void setActionTypeCode(String actionTypeCode) {
		this.actionTypeCode = actionTypeCode;
	}

	public String getAdviceBookId() {
		return this.adviceBookId;
	}

	public void setAdviceBookId(String adviceBookId) {
		this.adviceBookId = adviceBookId;
	}

	public String getAdviceBranchCode() {
		return this.adviceBranchCode;
	}

	public void setAdviceBranchCode(String adviceBranchCode) {
		this.adviceBranchCode = adviceBranchCode;
	}

	public Date getAdviceDate() {
		return this.adviceDate;
	}

	public void setAdviceDate(Date adviceDate) {
		this.adviceDate = adviceDate;
	}

	public BigDecimal getAdviceHdrId() {
		return this.adviceHdrId;
	}

	public void setAdviceHdrId(BigDecimal adviceHdrId) {
		this.adviceHdrId = adviceHdrId;
	}

	public BigDecimal getAdviceNo() {
		return this.adviceNo;
	}

	public void setAdviceNo(BigDecimal adviceNo) {
		this.adviceNo = adviceNo;
	}

	public BigDecimal getAdvicePrintCount() {
		return this.advicePrintCount;
	}

	public void setAdvicePrintCount(BigDecimal advicePrintCount) {
		this.advicePrintCount = advicePrintCount;
	}

	public String getAdvicePrintedBy() {
		return this.advicePrintedBy;
	}

	public void setAdvicePrintedBy(String advicePrintedBy) {
		this.advicePrintedBy = advicePrintedBy;
	}

	public Date getAdvicePrintedDate() {
		return this.advicePrintedDate;
	}

	public void setAdvicePrintedDate(Date advicePrintedDate) {
		this.advicePrintedDate = advicePrintedDate;
	}

	public String getApplicationCode() {
		return this.applicationCode;
	}

	public void setApplicationCode(String applicationCode) {
		this.applicationCode = applicationCode;
	}

	public Object getAuditLog() {
		return this.auditLog;
	}

	public void setAuditLog(Object auditLog) {
		this.auditLog = auditLog;
	}

	public String getAuthControlInd() {
		return this.authControlInd;
	}

	public void setAuthControlInd(String authControlInd) {
		this.authControlInd = authControlInd;
	}

	public Object getAuthDetails() {
		return this.authDetails;
	}

	public void setAuthDetails(Object authDetails) {
		this.authDetails = authDetails;
	}

	public Date getBankRefDate() {
		return this.bankRefDate;
	}

	public void setBankRefDate(Date bankRefDate) {
		this.bankRefDate = bankRefDate;
	}

	public String getBankRefNo() {
		return this.bankRefNo;
	}

	public void setBankRefNo(String bankRefNo) {
		this.bankRefNo = bankRefNo;
	}

	public String getBeneficiaryAcctNo() {
		return this.beneficiaryAcctNo;
	}

	public void setBeneficiaryAcctNo(String beneficiaryAcctNo) {
		this.beneficiaryAcctNo = beneficiaryAcctNo;
	}

	public BigDecimal getBeneficiaryAcctType() {
		return this.beneficiaryAcctType;
	}

	public void setBeneficiaryAcctType(BigDecimal beneficiaryAcctType) {
		this.beneficiaryAcctType = beneficiaryAcctType;
	}

	public String getBeneficiaryBank() {
		return this.beneficiaryBank;
	}

	public void setBeneficiaryBank(String beneficiaryBank) {
		this.beneficiaryBank = beneficiaryBank;
	}

	public String getBeneficiaryBankBranch() {
		return this.beneficiaryBankBranch;
	}

	public void setBeneficiaryBankBranch(String beneficiaryBankBranch) {
		this.beneficiaryBankBranch = beneficiaryBankBranch;
	}

	public BigDecimal getBeneficiaryBankBranchId() {
		return this.beneficiaryBankBranchId;
	}

	public void setBeneficiaryBankBranchId(BigDecimal beneficiaryBankBranchId) {
		this.beneficiaryBankBranchId = beneficiaryBankBranchId;
	}

	public BigDecimal getBeneficiaryBankId() {
		return this.beneficiaryBankId;
	}

	public void setBeneficiaryBankId(BigDecimal beneficiaryBankId) {
		this.beneficiaryBankId = beneficiaryBankId;
	}

	public String getCancelledBy() {
		return this.cancelledBy;
	}

	public void setCancelledBy(String cancelledBy) {
		this.cancelledBy = cancelledBy;
	}

	public Date getCancelledDate() {
		return this.cancelledDate;
	}

	public void setCancelledDate(Date cancelledDate) {
		this.cancelledDate = cancelledDate;
	}

	public String getCancelledRemarks() {
		return this.cancelledRemarks;
	}

	public void setCancelledRemarks(String cancelledRemarks) {
		this.cancelledRemarks = cancelledRemarks;
	}

	public String getChqBookStatus() {
		return this.chqBookStatus;
	}

	public void setChqBookStatus(String chqBookStatus) {
		this.chqBookStatus = chqBookStatus;
	}

	public BigDecimal getChqPrintCount() {
		return this.chqPrintCount;
	}

	public void setChqPrintCount(BigDecimal chqPrintCount) {
		this.chqPrintCount = chqPrintCount;
	}

	public String getChqPrintedBy() {
		return this.chqPrintedBy;
	}

	public void setChqPrintedBy(String chqPrintedBy) {
		this.chqPrintedBy = chqPrintedBy;
	}

	public Date getChqPrintedDate() {
		return this.chqPrintedDate;
	}

	public void setChqPrintedDate(Date chqPrintedDate) {
		this.chqPrintedDate = chqPrintedDate;
	}

	public String getCompanyCode() {
		return this.companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public BigDecimal getContactId() {
		return this.contactId;
	}

	public void setContactId(BigDecimal contactId) {
		this.contactId = contactId;
	}

	public String getContactRole() {
		return this.contactRole;
	}

	public void setContactRole(String contactRole) {
		this.contactRole = contactRole;
	}

	public BigDecimal getCoveringLetterPrintCount() {
		return this.coveringLetterPrintCount;
	}

	public void setCoveringLetterPrintCount(BigDecimal coveringLetterPrintCount) {
		this.coveringLetterPrintCount = coveringLetterPrintCount;
	}

	public String getCoveringLetterPrintedBy() {
		return this.coveringLetterPrintedBy;
	}

	public void setCoveringLetterPrintedBy(String coveringLetterPrintedBy) {
		this.coveringLetterPrintedBy = coveringLetterPrintedBy;
	}

	public Date getCoveringLetterPrintedDate() {
		return this.coveringLetterPrintedDate;
	}

	public void setCoveringLetterPrintedDate(Date coveringLetterPrintedDate) {
		this.coveringLetterPrintedDate = coveringLetterPrintedDate;
	}

	public BigDecimal getCrActivityId() {
		return this.crActivityId;
	}

	public void setCrActivityId(BigDecimal crActivityId) {
		this.crActivityId = crActivityId;
	}

	public BigDecimal getCrBranchId() {
		return this.crBranchId;
	}

	public void setCrBranchId(BigDecimal crBranchId) {
		this.crBranchId = crBranchId;
	}

	public BigDecimal getCrGlAcctId() {
		return this.crGlAcctId;
	}

	public void setCrGlAcctId(BigDecimal crGlAcctId) {
		this.crGlAcctId = crGlAcctId;
	}

	public String getCrSegment5Name() {
		return this.crSegment5Name;
	}

	public void setCrSegment5Name(String crSegment5Name) {
		this.crSegment5Name = crSegment5Name;
	}

	public BigDecimal getCrSegment5ValueId() {
		return this.crSegment5ValueId;
	}

	public void setCrSegment5ValueId(BigDecimal crSegment5ValueId) {
		this.crSegment5ValueId = crSegment5ValueId;
	}

	public String getCrSubglType() {
		return this.crSubglType;
	}

	public void setCrSubglType(String crSubglType) {
		this.crSubglType = crSubglType;
	}

	public BigDecimal getCrSubglValueId() {
		return this.crSubglValueId;
	}

	public void setCrSubglValueId(BigDecimal crSubglValueId) {
		this.crSubglValueId = crSubglValueId;
	}

	public String getCurrencyCode() {
		return this.currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public String getDraweePlace() {
		return this.draweePlace;
	}

	public void setDraweePlace(String draweePlace) {
		this.draweePlace = draweePlace;
	}

	public Date getEndTime() {
		return this.endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public String getFavoringName() {
		return this.favoringName;
	}

	public void setFavoringName(String favoringName) {
		this.favoringName = favoringName;
	}

	public String getFavouringNameOption() {
		return this.favouringNameOption;
	}

	public void setFavouringNameOption(String favouringNameOption) {
		this.favouringNameOption = favouringNameOption;
	}

	public String getIfsc() {
		return this.ifsc;
	}

	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}

	public BigDecimal getInstBookKeyId() {
		return this.instBookKeyId;
	}

	public void setInstBookKeyId(BigDecimal instBookKeyId) {
		this.instBookKeyId = instBookKeyId;
	}

	public Date getInstDate() {
		return this.instDate;
	}

	public void setInstDate(Date instDate) {
		this.instDate = instDate;
	}

	public BigDecimal getInstNo() {
		return this.instNo;
	}

	public void setInstNo(BigDecimal instNo) {
		this.instNo = instNo;
	}

	public String getInstType() {
		return this.instType;
	}

	public void setInstType(String instType) {
		this.instType = instType;
	}

	public BigDecimal getLedgerHdrId() {
		return this.ledgerHdrId;
	}

	public void setLedgerHdrId(BigDecimal ledgerHdrId) {
		this.ledgerHdrId = ledgerHdrId;
	}

	public String getModuleCode() {
		return this.moduleCode;
	}

	public void setModuleCode(String moduleCode) {
		this.moduleCode = moduleCode;
	}

	public String getPymtOption() {
		return this.pymtOption;
	}

	public void setPymtOption(String pymtOption) {
		this.pymtOption = pymtOption;
	}

	public String getPymtRemarks() {
		return this.pymtRemarks;
	}

	public void setPymtRemarks(String pymtRemarks) {
		this.pymtRemarks = pymtRemarks;
	}

	public String getRevBookId() {
		return this.revBookId;
	}

	public void setRevBookId(String revBookId) {
		this.revBookId = revBookId;
	}

	public String getRevBranchCode() {
		return this.revBranchCode;
	}

	public void setRevBranchCode(String revBranchCode) {
		this.revBranchCode = revBranchCode;
	}

	public BigDecimal getRevLedgerHdrId() {
		return this.revLedgerHdrId;
	}

	public void setRevLedgerHdrId(BigDecimal revLedgerHdrId) {
		this.revLedgerHdrId = revLedgerHdrId;
	}

	public BigDecimal getRevVoucherNo() {
		return this.revVoucherNo;
	}

	public void setRevVoucherNo(BigDecimal revVoucherNo) {
		this.revVoucherNo = revVoucherNo;
	}

	public String getReversalApprovalStatus() {
		return this.reversalApprovalStatus;
	}

	public void setReversalApprovalStatus(String reversalApprovalStatus) {
		this.reversalApprovalStatus = reversalApprovalStatus;
	}

	public Date getReversalApprovedDate() {
		return this.reversalApprovedDate;
	}

	public void setReversalApprovedDate(Date reversalApprovedDate) {
		this.reversalApprovedDate = reversalApprovedDate;
	}

	public String getReversalApprovedUser() {
		return this.reversalApprovedUser;
	}

	public void setReversalApprovedUser(String reversalApprovedUser) {
		this.reversalApprovedUser = reversalApprovedUser;
	}

	public Date getReversalRequestedDate() {
		return this.reversalRequestedDate;
	}

	public void setReversalRequestedDate(Date reversalRequestedDate) {
		this.reversalRequestedDate = reversalRequestedDate;
	}

	public String getReversalRequestedUser() {
		return this.reversalRequestedUser;
	}

	public void setReversalRequestedUser(String reversalRequestedUser) {
		this.reversalRequestedUser = reversalRequestedUser;
	}

	public Date getStartTime() {
		return this.startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public BigDecimal getVoucherAmt() {
		return this.voucherAmt;
	}

	public void setVoucherAmt(BigDecimal voucherAmt) {
		this.voucherAmt = voucherAmt;
	}

	public String getVoucherBookId() {
		return this.voucherBookId;
	}

	public void setVoucherBookId(String voucherBookId) {
		this.voucherBookId = voucherBookId;
	}

	public String getVoucherBranchCode() {
		return this.voucherBranchCode;
	}

	public void setVoucherBranchCode(String voucherBranchCode) {
		this.voucherBranchCode = voucherBranchCode;
	}

	public BigDecimal getVoucherBranchId() {
		return this.voucherBranchId;
	}

	public void setVoucherBranchId(BigDecimal voucherBranchId) {
		this.voucherBranchId = voucherBranchId;
	}

	public Date getVoucherDate() {
		return this.voucherDate;
	}

	public void setVoucherDate(Date voucherDate) {
		this.voucherDate = voucherDate;
	}

	public BigDecimal getVoucherNo() {
		return this.voucherNo;
	}

	public void setVoucherNo(BigDecimal voucherNo) {
		this.voucherNo = voucherNo;
	}

	public BigDecimal getVoucherPrintCount() {
		return this.voucherPrintCount;
	}

	public void setVoucherPrintCount(BigDecimal voucherPrintCount) {
		this.voucherPrintCount = voucherPrintCount;
	}

	public String getVoucherPrintedBy() {
		return this.voucherPrintedBy;
	}

	public void setVoucherPrintedBy(String voucherPrintedBy) {
		this.voucherPrintedBy = voucherPrintedBy;
	}

	public Date getVoucherPrintedDate() {
		return this.voucherPrintedDate;
	}

	public void setVoucherPrintedDate(Date voucherPrintedDate) {
		this.voucherPrintedDate = voucherPrintedDate;
	}

	public String getVoucherStatus() {
		return this.voucherStatus;
	}

	public void setVoucherStatus(String voucherStatus) {
		this.voucherStatus = voucherStatus;
	}

	public String getVoucherTypeAbbr() {
		return this.voucherTypeAbbr;
	}

	public void setVoucherTypeAbbr(String voucherTypeAbbr) {
		this.voucherTypeAbbr = voucherTypeAbbr;
	}

}