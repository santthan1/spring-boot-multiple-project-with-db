package in.sf.wcl.entity;

import java.io.Serializable;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the PS_TB_COM_ONLINE_PYMT_DTLS database table.
 * 
 */
@Entity
@Table(name="PS_TB_COM_ONLINE_PYMT_DTLS")
@NamedQuery(name="PsTbComOnlinePymtDtl.findAll", query="SELECT p FROM PsTbComOnlinePymtDtl p")
public class PsTbComOnlinePymtDtl implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ONLINE_REQUEST_ID")
	private long onlineRequestId;

	@Column(name="ACTION_TYPE_CODE")
	private String actionTypeCode;

	@Column(name="API_ID")
	private BigDecimal apiId;

	@Column(name="API_INST_TYPE")
	private String apiInstType;

	@Temporal(TemporalType.DATE)
	@Column(name="API_REQ_DATE")
	private Date apiReqDate;

	@Column(name="API_REQ_ID")
	private BigDecimal apiReqId;

	@Column(name="APPLICATION_CODE")
	private String applicationCode;

	@Column(name="AUTH_IND")
	private String authInd;

	@Column(name="AUTH_STATUS")
	private Object authStatus;

	@Column(name="BENEF_NAME_AS_BANK")
	private String benefNameAsBank;

	@Column(name="BENEFICIARY_ACCT_NO")
	private String beneficiaryAcctNo;

	@Column(name="BENEFICIARY_ACCT_TYPE")
	private String beneficiaryAcctType;

	@Column(name="BENEFICIARY_EMAIL_ID")
	private String beneficiaryEmailId;

	@Column(name="BENEFICIARY_IFSC_CODE")
	private String beneficiaryIfscCode;

	@Column(name="BENEFICIARY_MOBILE_NO")
	private String beneficiaryMobileNo;

	@Column(name="BENEFICIARY_RBI_BANK_BRANCH_ID")
	private BigDecimal beneficiaryRbiBankBranchId;

	@Column(name="BENEFICIARY_RBI_BANK_CODE")
	private String beneficiaryRbiBankCode;

	@Column(name="BENEFICIARY_RBI_BANK_ID")
	private BigDecimal beneficiaryRbiBankId;

	@Column(name="BOOK_RECORD_ID")
	private BigDecimal bookRecordId;

	@Temporal(TemporalType.DATE)
	@Column(name="CALL_BACK_DATE")
	private Date callBackDate;

	@Column(name="CALL_BACK_RECR_IND")
	private String callBackRecrInd;

	@Column(name="CALL_BACK_STATUS")
	private String callBackStatus;

	@Column(name="COMPANY_CODE")
	private String companyCode;

	@Column(name="COMPONENT_CODE")
	private String componentCode;

	@Column(name="CONTACT_BANK_ID")
	private BigDecimal contactBankId;

	@Column(name="CR_REF_NO")
	private String crRefNo;

	@Column(name="CURRENCY_CODE")
	private String currencyCode;

	@Column(name="DISBURSEMENT_TYPE")
	private String disbursementType;

	@Column(name="DR_REF_NO")
	private String drRefNo;

	@Column(name="FAVOURING_NAME")
	private String favouringName;

	@Column(name="INSTRUMENT_TYPE")
	private String instrumentType;

	@Column(name="MODULE_CODE")
	private String moduleCode;

	@Column(name="ONLINE_PYMT_TYPE_DESC")
	private String onlinePymtTypeDesc;

	@Temporal(TemporalType.DATE)
	@Column(name="ONLINE_REQUEST_DATE")
	private Date onlineRequestDate;

	@Column(name="PAYMENT_AMOUNT")
	private BigDecimal paymentAmount;

	@Temporal(TemporalType.DATE)
	@Column(name="PAYMENT_DATE")
	private Date paymentDate;

	@Column(name="PAYMENT_REMARKS")
	private String paymentRemarks;

	@Column(name="PS_REASON_CODE")
	private String psReasonCode;

	@Column(name="PV_REFERENCE")
	private String pvReference;

	@Column(name="PYMT_CAPPING_AMOUNT")
	private BigDecimal pymtCappingAmount;

	@Column(name="PYMT_DEPT_EMAIL_ID")
	private String pymtDeptEmailId;

	@Column(name="PYMT_REQ_CANCELLED_BY")
	private String pymtReqCancelledBy;

	@Temporal(TemporalType.DATE)
	@Column(name="PYMT_REQ_CANCELLED_DATE")
	private Date pymtReqCancelledDate;

	@Column(name="PYMT_REQ_CANCELLED_REMARKS")
	private String pymtReqCancelledRemarks;

	@Column(name="PYMT_STATUS")
	private String pymtStatus;

	@Column(name="RE_STATUS_API_ID")
	private BigDecimal reStatusApiId;

	@Column(name="REF_BOOK_ID")
	private String refBookId;

	@Column(name="REF_BRANCH_CODE")
	private String refBranchCode;

	@Temporal(TemporalType.DATE)
	@Column(name="REF_DATE")
	private Date refDate;

	@Column(name="REF_HDR_ID")
	private BigDecimal refHdrId;

	@Column(name="REF_NO")
	private BigDecimal refNo;

	@Column(name="REQ_FIRST_AUTH_USER_ID")
	private String reqFirstAuthUserId;

	@Column(name="REQ_REF_CODE")
	private String reqRefCode;

	@Column(name="REQ_SECOND_AUTH_USER_ID")
	private String reqSecondAuthUserId;

	@Column(name="REQUEST_BY")
	private String requestBy;

	@Column(name="RESP_REF_CODE")
	private String respRefCode;

	@Column(name="STATUS_API_ID")
	private BigDecimal statusApiId;

	@Column(name="TRANS_REF1")
	private String transRef1;

	@Column(name="TRANS_REF2")
	private String transRef2;

	@Column(name="TRANS_REF3")
	private String transRef3;

	@Column(name="TRANS_REF4")
	private String transRef4;

	@Column(name="TRANS_REF5")
	private String transRef5;

	@Temporal(TemporalType.DATE)
	@Column(name="UTR_DATE")
	private Date utrDate;

	@Column(name="UTR_NO")
	private String utrNo;

	//bi-directional many-to-one association to PsTbComOnlinePendPymtDtl
	@OneToMany(mappedBy="psTbComOnlinePymtDtl")
	private List<PsTbComOnlinePendPymtDtl> psTbComOnlinePendPymtDtls;

	public PsTbComOnlinePymtDtl() {
	}

	public long getOnlineRequestId() {
		return this.onlineRequestId;
	}

	public void setOnlineRequestId(long onlineRequestId) {
		this.onlineRequestId = onlineRequestId;
	}

	public String getActionTypeCode() {
		return this.actionTypeCode;
	}

	public void setActionTypeCode(String actionTypeCode) {
		this.actionTypeCode = actionTypeCode;
	}

	public BigDecimal getApiId() {
		return this.apiId;
	}

	public void setApiId(BigDecimal apiId) {
		this.apiId = apiId;
	}

	public String getApiInstType() {
		return this.apiInstType;
	}

	public void setApiInstType(String apiInstType) {
		this.apiInstType = apiInstType;
	}

	public Date getApiReqDate() {
		return this.apiReqDate;
	}

	public void setApiReqDate(Date apiReqDate) {
		this.apiReqDate = apiReqDate;
	}

	public BigDecimal getApiReqId() {
		return this.apiReqId;
	}

	public void setApiReqId(BigDecimal apiReqId) {
		this.apiReqId = apiReqId;
	}

	public String getApplicationCode() {
		return this.applicationCode;
	}

	public void setApplicationCode(String applicationCode) {
		this.applicationCode = applicationCode;
	}

	public String getAuthInd() {
		return this.authInd;
	}

	public void setAuthInd(String authInd) {
		this.authInd = authInd;
	}

	public Object getAuthStatus() {
		return this.authStatus;
	}

	public void setAuthStatus(Object authStatus) {
		this.authStatus = authStatus;
	}

	public String getBenefNameAsBank() {
		return this.benefNameAsBank;
	}

	public void setBenefNameAsBank(String benefNameAsBank) {
		this.benefNameAsBank = benefNameAsBank;
	}

	public String getBeneficiaryAcctNo() {
		return this.beneficiaryAcctNo;
	}

	public void setBeneficiaryAcctNo(String beneficiaryAcctNo) {
		this.beneficiaryAcctNo = beneficiaryAcctNo;
	}

	public String getBeneficiaryAcctType() {
		return this.beneficiaryAcctType;
	}

	public void setBeneficiaryAcctType(String beneficiaryAcctType) {
		this.beneficiaryAcctType = beneficiaryAcctType;
	}

	public String getBeneficiaryEmailId() {
		return this.beneficiaryEmailId;
	}

	public void setBeneficiaryEmailId(String beneficiaryEmailId) {
		this.beneficiaryEmailId = beneficiaryEmailId;
	}

	public String getBeneficiaryIfscCode() {
		return this.beneficiaryIfscCode;
	}

	public void setBeneficiaryIfscCode(String beneficiaryIfscCode) {
		this.beneficiaryIfscCode = beneficiaryIfscCode;
	}

	public String getBeneficiaryMobileNo() {
		return this.beneficiaryMobileNo;
	}

	public void setBeneficiaryMobileNo(String beneficiaryMobileNo) {
		this.beneficiaryMobileNo = beneficiaryMobileNo;
	}

	public BigDecimal getBeneficiaryRbiBankBranchId() {
		return this.beneficiaryRbiBankBranchId;
	}

	public void setBeneficiaryRbiBankBranchId(BigDecimal beneficiaryRbiBankBranchId) {
		this.beneficiaryRbiBankBranchId = beneficiaryRbiBankBranchId;
	}

	public String getBeneficiaryRbiBankCode() {
		return this.beneficiaryRbiBankCode;
	}

	public void setBeneficiaryRbiBankCode(String beneficiaryRbiBankCode) {
		this.beneficiaryRbiBankCode = beneficiaryRbiBankCode;
	}

	public BigDecimal getBeneficiaryRbiBankId() {
		return this.beneficiaryRbiBankId;
	}

	public void setBeneficiaryRbiBankId(BigDecimal beneficiaryRbiBankId) {
		this.beneficiaryRbiBankId = beneficiaryRbiBankId;
	}

	public BigDecimal getBookRecordId() {
		return this.bookRecordId;
	}

	public void setBookRecordId(BigDecimal bookRecordId) {
		this.bookRecordId = bookRecordId;
	}

	public Date getCallBackDate() {
		return this.callBackDate;
	}

	public void setCallBackDate(Date callBackDate) {
		this.callBackDate = callBackDate;
	}

	public String getCallBackRecrInd() {
		return this.callBackRecrInd;
	}

	public void setCallBackRecrInd(String callBackRecrInd) {
		this.callBackRecrInd = callBackRecrInd;
	}

	public String getCallBackStatus() {
		return this.callBackStatus;
	}

	public void setCallBackStatus(String callBackStatus) {
		this.callBackStatus = callBackStatus;
	}

	public String getCompanyCode() {
		return this.companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getComponentCode() {
		return this.componentCode;
	}

	public void setComponentCode(String componentCode) {
		this.componentCode = componentCode;
	}

	public BigDecimal getContactBankId() {
		return this.contactBankId;
	}

	public void setContactBankId(BigDecimal contactBankId) {
		this.contactBankId = contactBankId;
	}

	public String getCrRefNo() {
		return this.crRefNo;
	}

	public void setCrRefNo(String crRefNo) {
		this.crRefNo = crRefNo;
	}

	public String getCurrencyCode() {
		return this.currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public String getDisbursementType() {
		return this.disbursementType;
	}

	public void setDisbursementType(String disbursementType) {
		this.disbursementType = disbursementType;
	}

	public String getDrRefNo() {
		return this.drRefNo;
	}

	public void setDrRefNo(String drRefNo) {
		this.drRefNo = drRefNo;
	}

	public String getFavouringName() {
		return this.favouringName;
	}

	public void setFavouringName(String favouringName) {
		this.favouringName = favouringName;
	}

	public String getInstrumentType() {
		return this.instrumentType;
	}

	public void setInstrumentType(String instrumentType) {
		this.instrumentType = instrumentType;
	}

	public String getModuleCode() {
		return this.moduleCode;
	}

	public void setModuleCode(String moduleCode) {
		this.moduleCode = moduleCode;
	}

	public String getOnlinePymtTypeDesc() {
		return this.onlinePymtTypeDesc;
	}

	public void setOnlinePymtTypeDesc(String onlinePymtTypeDesc) {
		this.onlinePymtTypeDesc = onlinePymtTypeDesc;
	}

	public Date getOnlineRequestDate() {
		return this.onlineRequestDate;
	}

	public void setOnlineRequestDate(Date onlineRequestDate) {
		this.onlineRequestDate = onlineRequestDate;
	}

	public BigDecimal getPaymentAmount() {
		return this.paymentAmount;
	}

	public void setPaymentAmount(BigDecimal paymentAmount) {
		this.paymentAmount = paymentAmount;
	}

	public Date getPaymentDate() {
		return this.paymentDate;
	}

	public void setPaymentDate(Date paymentDate) {
		this.paymentDate = paymentDate;
	}

	public String getPaymentRemarks() {
		return this.paymentRemarks;
	}

	public void setPaymentRemarks(String paymentRemarks) {
		this.paymentRemarks = paymentRemarks;
	}

	public String getPsReasonCode() {
		return this.psReasonCode;
	}

	public void setPsReasonCode(String psReasonCode) {
		this.psReasonCode = psReasonCode;
	}

	public String getPvReference() {
		return this.pvReference;
	}

	public void setPvReference(String pvReference) {
		this.pvReference = pvReference;
	}

	public BigDecimal getPymtCappingAmount() {
		return this.pymtCappingAmount;
	}

	public void setPymtCappingAmount(BigDecimal pymtCappingAmount) {
		this.pymtCappingAmount = pymtCappingAmount;
	}

	public String getPymtDeptEmailId() {
		return this.pymtDeptEmailId;
	}

	public void setPymtDeptEmailId(String pymtDeptEmailId) {
		this.pymtDeptEmailId = pymtDeptEmailId;
	}

	public String getPymtReqCancelledBy() {
		return this.pymtReqCancelledBy;
	}

	public void setPymtReqCancelledBy(String pymtReqCancelledBy) {
		this.pymtReqCancelledBy = pymtReqCancelledBy;
	}

	public Date getPymtReqCancelledDate() {
		return this.pymtReqCancelledDate;
	}

	public void setPymtReqCancelledDate(Date pymtReqCancelledDate) {
		this.pymtReqCancelledDate = pymtReqCancelledDate;
	}

	public String getPymtReqCancelledRemarks() {
		return this.pymtReqCancelledRemarks;
	}

	public void setPymtReqCancelledRemarks(String pymtReqCancelledRemarks) {
		this.pymtReqCancelledRemarks = pymtReqCancelledRemarks;
	}

	public String getPymtStatus() {
		return this.pymtStatus;
	}

	public void setPymtStatus(String pymtStatus) {
		this.pymtStatus = pymtStatus;
	}

	public BigDecimal getReStatusApiId() {
		return this.reStatusApiId;
	}

	public void setReStatusApiId(BigDecimal reStatusApiId) {
		this.reStatusApiId = reStatusApiId;
	}

	public String getRefBookId() {
		return this.refBookId;
	}

	public void setRefBookId(String refBookId) {
		this.refBookId = refBookId;
	}

	public String getRefBranchCode() {
		return this.refBranchCode;
	}

	public void setRefBranchCode(String refBranchCode) {
		this.refBranchCode = refBranchCode;
	}

	public Date getRefDate() {
		return this.refDate;
	}

	public void setRefDate(Date refDate) {
		this.refDate = refDate;
	}

	public BigDecimal getRefHdrId() {
		return this.refHdrId;
	}

	public void setRefHdrId(BigDecimal refHdrId) {
		this.refHdrId = refHdrId;
	}

	public BigDecimal getRefNo() {
		return this.refNo;
	}

	public void setRefNo(BigDecimal refNo) {
		this.refNo = refNo;
	}

	public String getReqFirstAuthUserId() {
		return this.reqFirstAuthUserId;
	}

	public void setReqFirstAuthUserId(String reqFirstAuthUserId) {
		this.reqFirstAuthUserId = reqFirstAuthUserId;
	}

	public String getReqRefCode() {
		return this.reqRefCode;
	}

	public void setReqRefCode(String reqRefCode) {
		this.reqRefCode = reqRefCode;
	}

	public String getReqSecondAuthUserId() {
		return this.reqSecondAuthUserId;
	}

	public void setReqSecondAuthUserId(String reqSecondAuthUserId) {
		this.reqSecondAuthUserId = reqSecondAuthUserId;
	}

	public String getRequestBy() {
		return this.requestBy;
	}

	public void setRequestBy(String requestBy) {
		this.requestBy = requestBy;
	}

	public String getRespRefCode() {
		return this.respRefCode;
	}

	public void setRespRefCode(String respRefCode) {
		this.respRefCode = respRefCode;
	}

	public BigDecimal getStatusApiId() {
		return this.statusApiId;
	}

	public void setStatusApiId(BigDecimal statusApiId) {
		this.statusApiId = statusApiId;
	}

	public String getTransRef1() {
		return this.transRef1;
	}

	public void setTransRef1(String transRef1) {
		this.transRef1 = transRef1;
	}

	public String getTransRef2() {
		return this.transRef2;
	}

	public void setTransRef2(String transRef2) {
		this.transRef2 = transRef2;
	}

	public String getTransRef3() {
		return this.transRef3;
	}

	public void setTransRef3(String transRef3) {
		this.transRef3 = transRef3;
	}

	public String getTransRef4() {
		return this.transRef4;
	}

	public void setTransRef4(String transRef4) {
		this.transRef4 = transRef4;
	}

	public String getTransRef5() {
		return this.transRef5;
	}

	public void setTransRef5(String transRef5) {
		this.transRef5 = transRef5;
	}

	public Date getUtrDate() {
		return this.utrDate;
	}

	public void setUtrDate(Date utrDate) {
		this.utrDate = utrDate;
	}

	public String getUtrNo() {
		return this.utrNo;
	}

	public void setUtrNo(String utrNo) {
		this.utrNo = utrNo;
	}

	public List<PsTbComOnlinePendPymtDtl> getPsTbComOnlinePendPymtDtls() {
		return this.psTbComOnlinePendPymtDtls;
	}

	public void setPsTbComOnlinePendPymtDtls(List<PsTbComOnlinePendPymtDtl> psTbComOnlinePendPymtDtls) {
		this.psTbComOnlinePendPymtDtls = psTbComOnlinePendPymtDtls;
	}

	public PsTbComOnlinePendPymtDtl addPsTbComOnlinePendPymtDtl(PsTbComOnlinePendPymtDtl psTbComOnlinePendPymtDtl) {
		getPsTbComOnlinePendPymtDtls().add(psTbComOnlinePendPymtDtl);
		psTbComOnlinePendPymtDtl.setPsTbComOnlinePymtDtl(this);

		return psTbComOnlinePendPymtDtl;
	}

	public PsTbComOnlinePendPymtDtl removePsTbComOnlinePendPymtDtl(PsTbComOnlinePendPymtDtl psTbComOnlinePendPymtDtl) {
		getPsTbComOnlinePendPymtDtls().remove(psTbComOnlinePendPymtDtl);
		psTbComOnlinePendPymtDtl.setPsTbComOnlinePymtDtl(null);

		return psTbComOnlinePendPymtDtl;
	}

}