package in.sf.wcl.entity;

import java.io.Serializable;
import jakarta.persistence.*;


/**
 * The persistent class for the PS_TB_LN_CONT_FUNDING_DTLS database table.
 * 
 */
@Entity
@Table(name="PS_TB_LN_CONT_FUNDING_DTLS")
@NamedQuery(name="PsTbLnContFundingDtl.findAll", query="SELECT p FROM PsTbLnContFundingDtl p")
public class PsTbLnContFundingDtl implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="COMPANY_CODE")
	private String companyCode;

	@Column(name="CONTRACT_NO")
	private String contractNo;

	@Column(name="PRODUCT_CODE")
	private String productCode;

	@Column(name="SEGMENT_CODE")
	private String segmentCode;

	public PsTbLnContFundingDtl() {
	}

	public String getCompanyCode() {
		return this.companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getContractNo() {
		return this.contractNo;
	}

	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}

	public String getProductCode() {
		return this.productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getSegmentCode() {
		return this.segmentCode;
	}

	public void setSegmentCode(String segmentCode) {
		this.segmentCode = segmentCode;
	}

}