package in.sf.wcl.entity;

import java.io.Serializable;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the PS_TB_LN_DO_MAIL_DTLS database table.
 * 
 */
@Entity
@Table(name="PS_TB_LN_DO_MAIL_DTLS")
@NamedQuery(name="PsTbLnDoMailDtl.findAll", query="SELECT p FROM PsTbLnDoMailDtl p")
public class PsTbLnDoMailDtl implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="COMPANY_CODE")
	private String companyCode;

	@Column(name="CONTRACT_NO")
	private String contractNo;

	@Column(name="DO_RECORD_ID")
	private BigDecimal doRecordId;

	@Temporal(TemporalType.DATE)
	@Column(name="MAIL_DATE")
	private Date mailDate;

	private String remarks;

	@Column(name="SEQ_ID")
	private BigDecimal seqId;

	private String status;

	@Temporal(TemporalType.DATE)
	@Column(name="TXN_DATE")
	private Date txnDate;

	public PsTbLnDoMailDtl() {
	}

	public String getCompanyCode() {
		return this.companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getContractNo() {
		return this.contractNo;
	}

	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}

	public BigDecimal getDoRecordId() {
		return this.doRecordId;
	}

	public void setDoRecordId(BigDecimal doRecordId) {
		this.doRecordId = doRecordId;
	}

	public Date getMailDate() {
		return this.mailDate;
	}

	public void setMailDate(Date mailDate) {
		this.mailDate = mailDate;
	}

	public String getRemarks() {
		return this.remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public BigDecimal getSeqId() {
		return this.seqId;
	}

	public void setSeqId(BigDecimal seqId) {
		this.seqId = seqId;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getTxnDate() {
		return this.txnDate;
	}

	public void setTxnDate(Date txnDate) {
		this.txnDate = txnDate;
	}

}