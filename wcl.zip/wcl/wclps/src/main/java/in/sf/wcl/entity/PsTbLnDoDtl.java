package in.sf.wcl.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the PS_TB_LN_DO_DTLS database table.
 * 
 */
@Entity
@Table(name="PS_TB_LN_DO_DTLS")
@NamedQuery(name="PsTbLnDoDtl.findAll", query="SELECT p FROM PsTbLnDoDtl p")
public class PsTbLnDoDtl implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="DO_RECORD_ID")
	private long doRecordId;

	@Column(name="AUDIT_LOG")
	private Object auditLog;

	@Column(name="BOOK_ID")
	private String bookId;

	@Column(name="BRANCH_CODE")
	private String branchCode;

	@Column(name="CANCEL_REMARKS")
	private String cancelRemarks;

	@Column(name="CANCELLED_BY")
	private String cancelledBy;

	@Temporal(TemporalType.DATE)
	@Column(name="CANCELLED_DATE")
	private Date cancelledDate;

	@Column(name="COMPANY_CODE")
	private String companyCode;

	@Column(name="CONTRACT_NO")
	private String contractNo;

	@Temporal(TemporalType.DATE)
	@Column(name="DOC_DATE")
	private Date docDate;

	@Column(name="DOC_NO")
	private BigDecimal docNo;

	@Column(name="DOC_TYPE_ABBR")
	private String docTypeAbbr;

	@Temporal(TemporalType.DATE)
	@Column(name="END_TIME")
	private Date endTime;

	@Column(name="PYMT_TYPE")
	private String pymtType;

	private String remarks;

	@Temporal(TemporalType.DATE)
	@Column(name="START_TIME")
	private Date startTime;

	private String status;

	@Temporal(TemporalType.DATE)
	@Column(name="VALUE_DATE")
	private Date valueDate;

	//bi-directional many-to-one association to PsTbLnDoAdjDtl
	@OneToMany(mappedBy="psTbLnDoDtl")
	private List<PsTbLnDoAdjDtl> psTbLnDoAdjDtls;

	public PsTbLnDoDtl() {
	}

	public long getDoRecordId() {
		return this.doRecordId;
	}

	public void setDoRecordId(long doRecordId) {
		this.doRecordId = doRecordId;
	}

	public Object getAuditLog() {
		return this.auditLog;
	}

	public void setAuditLog(Object auditLog) {
		this.auditLog = auditLog;
	}

	public String getBookId() {
		return this.bookId;
	}

	public void setBookId(String bookId) {
		this.bookId = bookId;
	}

	public String getBranchCode() {
		return this.branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	public String getCancelRemarks() {
		return this.cancelRemarks;
	}

	public void setCancelRemarks(String cancelRemarks) {
		this.cancelRemarks = cancelRemarks;
	}

	public String getCancelledBy() {
		return this.cancelledBy;
	}

	public void setCancelledBy(String cancelledBy) {
		this.cancelledBy = cancelledBy;
	}

	public Date getCancelledDate() {
		return this.cancelledDate;
	}

	public void setCancelledDate(Date cancelledDate) {
		this.cancelledDate = cancelledDate;
	}

	public String getCompanyCode() {
		return this.companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getContractNo() {
		return this.contractNo;
	}

	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}

	public Date getDocDate() {
		return this.docDate;
	}

	public void setDocDate(Date docDate) {
		this.docDate = docDate;
	}

	public BigDecimal getDocNo() {
		return this.docNo;
	}

	public void setDocNo(BigDecimal docNo) {
		this.docNo = docNo;
	}

	public String getDocTypeAbbr() {
		return this.docTypeAbbr;
	}

	public void setDocTypeAbbr(String docTypeAbbr) {
		this.docTypeAbbr = docTypeAbbr;
	}

	public Date getEndTime() {
		return this.endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public String getPymtType() {
		return this.pymtType;
	}

	public void setPymtType(String pymtType) {
		this.pymtType = pymtType;
	}

	public String getRemarks() {
		return this.remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Date getStartTime() {
		return this.startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getValueDate() {
		return this.valueDate;
	}

	public void setValueDate(Date valueDate) {
		this.valueDate = valueDate;
	}

	public List<PsTbLnDoAdjDtl> getPsTbLnDoAdjDtls() {
		return this.psTbLnDoAdjDtls;
	}

	public void setPsTbLnDoAdjDtls(List<PsTbLnDoAdjDtl> psTbLnDoAdjDtls) {
		this.psTbLnDoAdjDtls = psTbLnDoAdjDtls;
	}

	public PsTbLnDoAdjDtl addPsTbLnDoAdjDtl(PsTbLnDoAdjDtl psTbLnDoAdjDtl) {
		getPsTbLnDoAdjDtls().add(psTbLnDoAdjDtl);
		psTbLnDoAdjDtl.setPsTbLnDoDtl(this);

		return psTbLnDoAdjDtl;
	}

	public PsTbLnDoAdjDtl removePsTbLnDoAdjDtl(PsTbLnDoAdjDtl psTbLnDoAdjDtl) {
		getPsTbLnDoAdjDtls().remove(psTbLnDoAdjDtl);
		psTbLnDoAdjDtl.setPsTbLnDoDtl(null);

		return psTbLnDoAdjDtl;
	}

}