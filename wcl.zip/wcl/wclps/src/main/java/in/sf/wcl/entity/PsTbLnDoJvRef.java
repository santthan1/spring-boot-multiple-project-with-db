package in.sf.wcl.entity;

import java.io.Serializable;
import jakarta.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the PS_TB_LN_DO_JV_REF database table.
 * 
 */
@Entity
@Table(name="PS_TB_LN_DO_JV_REF")
@NamedQuery(name="PsTbLnDoJvRef.findAll", query="SELECT p FROM PsTbLnDoJvRef p")
public class PsTbLnDoJvRef implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="DO_JV_REF_RECORD_ID")
	private long doJvRefRecordId;

	@Column(name="AUDIT_LOG")
	private Object auditLog;

	@Column(name="COMPANY_CODE")
	private String companyCode;

	@Column(name="CONTRACT_NO")
	private String contractNo;

	@Column(name="DO_ADJ_RECORD_ID")
	private BigDecimal doAdjRecordId;

	@Column(name="DO_BOOK_ID")
	private String doBookId;

	@Column(name="DO_BRANCH_CODE")
	private String doBranchCode;

	@Column(name="DO_DOC_NO")
	private BigDecimal doDocNo;

	@Column(name="JV_BOOK_ID")
	private String jvBookId;

	@Column(name="JV_BRANCH_CODE")
	private String jvBranchCode;

	@Column(name="JV_DOC_NO")
	private BigDecimal jvDocNo;

	public PsTbLnDoJvRef() {
	}

	public long getDoJvRefRecordId() {
		return this.doJvRefRecordId;
	}

	public void setDoJvRefRecordId(long doJvRefRecordId) {
		this.doJvRefRecordId = doJvRefRecordId;
	}

	public Object getAuditLog() {
		return this.auditLog;
	}

	public void setAuditLog(Object auditLog) {
		this.auditLog = auditLog;
	}

	public String getCompanyCode() {
		return this.companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getContractNo() {
		return this.contractNo;
	}

	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}

	public BigDecimal getDoAdjRecordId() {
		return this.doAdjRecordId;
	}

	public void setDoAdjRecordId(BigDecimal doAdjRecordId) {
		this.doAdjRecordId = doAdjRecordId;
	}

	public String getDoBookId() {
		return this.doBookId;
	}

	public void setDoBookId(String doBookId) {
		this.doBookId = doBookId;
	}

	public String getDoBranchCode() {
		return this.doBranchCode;
	}

	public void setDoBranchCode(String doBranchCode) {
		this.doBranchCode = doBranchCode;
	}

	public BigDecimal getDoDocNo() {
		return this.doDocNo;
	}

	public void setDoDocNo(BigDecimal doDocNo) {
		this.doDocNo = doDocNo;
	}

	public String getJvBookId() {
		return this.jvBookId;
	}

	public void setJvBookId(String jvBookId) {
		this.jvBookId = jvBookId;
	}

	public String getJvBranchCode() {
		return this.jvBranchCode;
	}

	public void setJvBranchCode(String jvBranchCode) {
		this.jvBranchCode = jvBranchCode;
	}

	public BigDecimal getJvDocNo() {
		return this.jvDocNo;
	}

	public void setJvDocNo(BigDecimal jvDocNo) {
		this.jvDocNo = jvDocNo;
	}

}