package in.sf.wcl.entity;

import jakarta.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the PS_TB_COM_ONLINE_PEND_PYMT_DTL database table.
 * 
 */
@Entity
@Table(name="PS_TB_COM_ONLINE_PEND_PYMT_DTL")
@NamedQuery(name="PsTbComOnlinePendPymtDtl.findAll", query="SELECT p FROM PsTbComOnlinePendPymtDtl p")
public class PsTbComOnlinePendPymtDtl implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ONLINE_PYMT_REQ_TRF_ID")
	private long onlinePymtReqTrfId;

	@Temporal(TemporalType.DATE)
	@Column(name="ADVICE_DATE")
	private Date adviceDate;

	@Column(name="ADVICE_REF")
	private String adviceRef;

	@Column(name="APPLICATION_CODE")
	private String applicationCode;

	@Column(name="AUDIT_LOG")
	private Object auditLog;

	@Column(name="BENEFICIARY_ACCT_NO")
	private String beneficiaryAcctNo;

	@Column(name="BENEFICIARY_ACCT_TYPE")
	private BigDecimal beneficiaryAcctType;

	@Column(name="BENEFICIARY_BANK_BRANCH_ID")
	private BigDecimal beneficiaryBankBranchId;

	@Column(name="BENEFICIARY_EMAIL")
	private String beneficiaryEmail;

	@Column(name="BENEFICIARY_MOBILE_NO")
	private String beneficiaryMobileNo;

	@Column(name="BRANCH_CODE")
	private String branchCode;

	@Column(name="BRANCH_ID")
	private BigDecimal branchId;

	@Column(name="CHARGES_TYPE")
	private String chargesType;

	@Temporal(TemporalType.DATE)
	@Column(name="COM_TRF_DATE")
	private Date comTrfDate;

	@Column(name="COM_TRF_ERR_REMARKS")
	private String comTrfErrRemarks;

	@Column(name="COM_TRF_IND")
	private String comTrfInd;

	@Column(name="COMPANY_CODE")
	private String companyCode;

	@Column(name="CONTACT_CODE")
	private String contactCode;

	@Column(name="CONTACT_ID")
	private BigDecimal contactId;

	@Column(name="CONTACT_NAME")
	private String contactName;

	@Column(name="CONTACT_ROLE")
	private String contactRole;

	@Column(name="CR_ACTIVITY_ID")
	private BigDecimal crActivityId;

	@Column(name="CR_BRANCH_ID")
	private BigDecimal crBranchId;

	@Column(name="CR_GL_ACCT_ID")
	private BigDecimal crGlAcctId;

	@Column(name="CR_SEGMENT5_NAME")
	private String crSegment5Name;

	@Column(name="CR_SEGMENT5_VALUE_ID")
	private BigDecimal crSegment5ValueId;

	@Column(name="CURRENCY_CODE")
	private String currencyCode;

	@Column(name="DD_PLACE_ID")
	private BigDecimal ddPlaceId;

	@Column(name="DOC_BOOK_ID")
	private String docBookId;

	@Temporal(TemporalType.DATE)
	@Column(name="DOC_DATE")
	private Date docDate;

	@Column(name="DOC_NO")
	private BigDecimal docNo;

	@Column(name="DOC_TYPE_ABBR")
	private String docTypeAbbr;

	@Column(name="DRAWEE_PLACE")
	private String draweePlace;

	@Column(name="FAVOURING_NAME")
	private String favouringName;

	@Column(name="FAVOURING_NAME_OPTION")
	private String favouringNameOption;

	private String ifsc;

	@Column(name="INSTRUMENT_TYPE")
	private String instrumentType;

	@Column(name="MODULE_CODE")
	private String moduleCode;

	@Column(name="PR_TYPE")
	private BigDecimal prType;

	@Column(name="PREFERRED_BANK_NAME")
	private String preferredBankName;

	@Column(name="REQUEST_AMOUNT")
	private BigDecimal requestAmount;

	@Column(name="REQUEST_HDR_ID")
	private BigDecimal requestHdrId;

	@Column(name="REQUEST_VOUCHER_IND")
	private String requestVoucherInd;

	@Column(name="SUBGL_TYPE")
	private String subglType;

	@Column(name="SUBGL_VALUE_ID")
	private BigDecimal subglValueId;

	//bi-directional many-to-one association to PsTbComOnlinePymtDtl
	@ManyToOne
	@JoinColumn(name="ONLINE_REQUEST_ID")
	private PsTbComOnlinePymtDtl psTbComOnlinePymtDtl;

	public PsTbComOnlinePendPymtDtl() {
	}

	public long getOnlinePymtReqTrfId() {
		return this.onlinePymtReqTrfId;
	}

	public void setOnlinePymtReqTrfId(long onlinePymtReqTrfId) {
		this.onlinePymtReqTrfId = onlinePymtReqTrfId;
	}

	public Date getAdviceDate() {
		return this.adviceDate;
	}

	public void setAdviceDate(Date adviceDate) {
		this.adviceDate = adviceDate;
	}

	public String getAdviceRef() {
		return this.adviceRef;
	}

	public void setAdviceRef(String adviceRef) {
		this.adviceRef = adviceRef;
	}

	public String getApplicationCode() {
		return this.applicationCode;
	}

	public void setApplicationCode(String applicationCode) {
		this.applicationCode = applicationCode;
	}

	public Object getAuditLog() {
		return this.auditLog;
	}

	public void setAuditLog(Object auditLog) {
		this.auditLog = auditLog;
	}

	public String getBeneficiaryAcctNo() {
		return this.beneficiaryAcctNo;
	}

	public void setBeneficiaryAcctNo(String beneficiaryAcctNo) {
		this.beneficiaryAcctNo = beneficiaryAcctNo;
	}

	public BigDecimal getBeneficiaryAcctType() {
		return this.beneficiaryAcctType;
	}

	public void setBeneficiaryAcctType(BigDecimal beneficiaryAcctType) {
		this.beneficiaryAcctType = beneficiaryAcctType;
	}

	public BigDecimal getBeneficiaryBankBranchId() {
		return this.beneficiaryBankBranchId;
	}

	public void setBeneficiaryBankBranchId(BigDecimal beneficiaryBankBranchId) {
		this.beneficiaryBankBranchId = beneficiaryBankBranchId;
	}

	public String getBeneficiaryEmail() {
		return this.beneficiaryEmail;
	}

	public void setBeneficiaryEmail(String beneficiaryEmail) {
		this.beneficiaryEmail = beneficiaryEmail;
	}

	public String getBeneficiaryMobileNo() {
		return this.beneficiaryMobileNo;
	}

	public void setBeneficiaryMobileNo(String beneficiaryMobileNo) {
		this.beneficiaryMobileNo = beneficiaryMobileNo;
	}

	public String getBranchCode() {
		return this.branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	public BigDecimal getBranchId() {
		return this.branchId;
	}

	public void setBranchId(BigDecimal branchId) {
		this.branchId = branchId;
	}

	public String getChargesType() {
		return this.chargesType;
	}

	public void setChargesType(String chargesType) {
		this.chargesType = chargesType;
	}

	public Date getComTrfDate() {
		return this.comTrfDate;
	}

	public void setComTrfDate(Date comTrfDate) {
		this.comTrfDate = comTrfDate;
	}

	public String getComTrfErrRemarks() {
		return this.comTrfErrRemarks;
	}

	public void setComTrfErrRemarks(String comTrfErrRemarks) {
		this.comTrfErrRemarks = comTrfErrRemarks;
	}

	public String getComTrfInd() {
		return this.comTrfInd;
	}

	public void setComTrfInd(String comTrfInd) {
		this.comTrfInd = comTrfInd;
	}

	public String getCompanyCode() {
		return this.companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getContactCode() {
		return this.contactCode;
	}

	public void setContactCode(String contactCode) {
		this.contactCode = contactCode;
	}

	public BigDecimal getContactId() {
		return this.contactId;
	}

	public void setContactId(BigDecimal contactId) {
		this.contactId = contactId;
	}

	public String getContactName() {
		return this.contactName;
	}

	public void setContactName(String contactName) {
		this.contactName = contactName;
	}

	public String getContactRole() {
		return this.contactRole;
	}

	public void setContactRole(String contactRole) {
		this.contactRole = contactRole;
	}

	public BigDecimal getCrActivityId() {
		return this.crActivityId;
	}

	public void setCrActivityId(BigDecimal crActivityId) {
		this.crActivityId = crActivityId;
	}

	public BigDecimal getCrBranchId() {
		return this.crBranchId;
	}

	public void setCrBranchId(BigDecimal crBranchId) {
		this.crBranchId = crBranchId;
	}

	public BigDecimal getCrGlAcctId() {
		return this.crGlAcctId;
	}

	public void setCrGlAcctId(BigDecimal crGlAcctId) {
		this.crGlAcctId = crGlAcctId;
	}

	public String getCrSegment5Name() {
		return this.crSegment5Name;
	}

	public void setCrSegment5Name(String crSegment5Name) {
		this.crSegment5Name = crSegment5Name;
	}

	public BigDecimal getCrSegment5ValueId() {
		return this.crSegment5ValueId;
	}

	public void setCrSegment5ValueId(BigDecimal crSegment5ValueId) {
		this.crSegment5ValueId = crSegment5ValueId;
	}

	public String getCurrencyCode() {
		return this.currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public BigDecimal getDdPlaceId() {
		return this.ddPlaceId;
	}

	public void setDdPlaceId(BigDecimal ddPlaceId) {
		this.ddPlaceId = ddPlaceId;
	}

	public String getDocBookId() {
		return this.docBookId;
	}

	public void setDocBookId(String docBookId) {
		this.docBookId = docBookId;
	}

	public Date getDocDate() {
		return this.docDate;
	}

	public void setDocDate(Date docDate) {
		this.docDate = docDate;
	}

	public BigDecimal getDocNo() {
		return this.docNo;
	}

	public void setDocNo(BigDecimal docNo) {
		this.docNo = docNo;
	}

	public String getDocTypeAbbr() {
		return this.docTypeAbbr;
	}

	public void setDocTypeAbbr(String docTypeAbbr) {
		this.docTypeAbbr = docTypeAbbr;
	}

	public String getDraweePlace() {
		return this.draweePlace;
	}

	public void setDraweePlace(String draweePlace) {
		this.draweePlace = draweePlace;
	}

	public String getFavouringName() {
		return this.favouringName;
	}

	public void setFavouringName(String favouringName) {
		this.favouringName = favouringName;
	}

	public String getFavouringNameOption() {
		return this.favouringNameOption;
	}

	public void setFavouringNameOption(String favouringNameOption) {
		this.favouringNameOption = favouringNameOption;
	}

	public String getIfsc() {
		return this.ifsc;
	}

	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}

	public String getInstrumentType() {
		return this.instrumentType;
	}

	public void setInstrumentType(String instrumentType) {
		this.instrumentType = instrumentType;
	}

	public String getModuleCode() {
		return this.moduleCode;
	}

	public void setModuleCode(String moduleCode) {
		this.moduleCode = moduleCode;
	}

	public BigDecimal getPrType() {
		return this.prType;
	}

	public void setPrType(BigDecimal prType) {
		this.prType = prType;
	}

	public String getPreferredBankName() {
		return this.preferredBankName;
	}

	public void setPreferredBankName(String preferredBankName) {
		this.preferredBankName = preferredBankName;
	}

	public BigDecimal getRequestAmount() {
		return this.requestAmount;
	}

	public void setRequestAmount(BigDecimal requestAmount) {
		this.requestAmount = requestAmount;
	}

	public BigDecimal getRequestHdrId() {
		return this.requestHdrId;
	}

	public void setRequestHdrId(BigDecimal requestHdrId) {
		this.requestHdrId = requestHdrId;
	}

	public String getRequestVoucherInd() {
		return this.requestVoucherInd;
	}

	public void setRequestVoucherInd(String requestVoucherInd) {
		this.requestVoucherInd = requestVoucherInd;
	}

	public String getSubglType() {
		return this.subglType;
	}

	public void setSubglType(String subglType) {
		this.subglType = subglType;
	}

	public BigDecimal getSubglValueId() {
		return this.subglValueId;
	}

	public void setSubglValueId(BigDecimal subglValueId) {
		this.subglValueId = subglValueId;
	}

	public PsTbComOnlinePymtDtl getPsTbComOnlinePymtDtl() {
		return this.psTbComOnlinePymtDtl;
	}

	public void setPsTbComOnlinePymtDtl(PsTbComOnlinePymtDtl psTbComOnlinePymtDtl) {
		this.psTbComOnlinePymtDtl = psTbComOnlinePymtDtl;
	}

}