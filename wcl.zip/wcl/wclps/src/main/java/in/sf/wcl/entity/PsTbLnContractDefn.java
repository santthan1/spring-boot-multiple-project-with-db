package in.sf.wcl.entity;

import java.io.Serializable;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the PS_TB_LN_CONTRACT_DEFN database table.
 * 
 */
@Entity
@Table(name="PS_TB_LN_CONTRACT_DEFN")
@NamedQuery(name="PsTbLnContractDefn.findAll", query="SELECT p FROM PsTbLnContractDefn p")
public class PsTbLnContractDefn implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private PsTbLnContractDefnPK id;

	@Column(name="ACTION_TYPE_CODE")
	private String actionTypeCode;

	@Temporal(TemporalType.DATE)
	@Column(name="AGREE_DATE")
	private Date agreeDate;

	@Column(name="APPLICATION_NO")
	private String applicationNo;

	@Temporal(TemporalType.DATE)
	@Column(name="APPROVAL_DATE")
	private Date approvalDate;

	@Column(name="APPROVED_BY")
	private String approvedBy;

	@Column(name="AUDIT_LOG")
	private Object auditLog;

	@Column(name="BASE_CONTRACT_NO")
	private String baseContractNo;

	@Column(name="BRANCH_CODE")
	private String branchCode;

	@Column(name="BU_BRANCH_CODE")
	private String buBranchCode;

	@Column(name="CLOSED_BY")
	private String closedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="CLOSURE_DATE")
	private Date closureDate;

	@Column(name="COMPANY_CODE")
	private String companyCode;

	@Temporal(TemporalType.DATE)
	@Column(name="CONFIG_DATE")
	private Date configDate;

	@Temporal(TemporalType.DATE)
	@Column(name="CONFIG_TXN_DATE")
	private Date configTxnDate;

	@Column(name="CONFIGURED_BY")
	private String configuredBy;

	@Column(name="CONTRACT_NO")
	private String contractNo;

	@Column(name="CONTRACT_STATUS")
	private String contractStatus;

	@Column(name="CONTRACT_TYPE")
	private BigDecimal contractType;

	@Column(name="CUSTOMER_CODE")
	private String customerCode;

	@Column(name="FIN_BY_SF")
	private String finBySf;

	@Column(name="GUARANTOR_CODE")
	private String guarantorCode;

	@Column(name="INSUR_BY_IND")
	private String insurByInd;

	@Temporal(TemporalType.DATE)
	@Column(name="PYMT_DATE")
	private Date pymtDate;

	@Column(name="SANCTION_HDR_ID")
	private BigDecimal sanctionHdrId;

	@Column(name="STMT_CODE")
	private BigDecimal stmtCode;

	@Temporal(TemporalType.DATE)
	@Column(name="TXN_DATE")
	private Date txnDate;

	@Column(name="VEHICLE_REGN_NO")
	private String vehicleRegnNo;

	public PsTbLnContractDefn() {
	}

	public PsTbLnContractDefnPK getId() {
		return this.id;
	}

	public void setId(PsTbLnContractDefnPK id) {
		this.id = id;
	}

	public String getActionTypeCode() {
		return this.actionTypeCode;
	}

	public void setActionTypeCode(String actionTypeCode) {
		this.actionTypeCode = actionTypeCode;
	}

	public Date getAgreeDate() {
		return this.agreeDate;
	}

	public void setAgreeDate(Date agreeDate) {
		this.agreeDate = agreeDate;
	}

	public String getApplicationNo() {
		return this.applicationNo;
	}

	public void setApplicationNo(String applicationNo) {
		this.applicationNo = applicationNo;
	}

	public Date getApprovalDate() {
		return this.approvalDate;
	}

	public void setApprovalDate(Date approvalDate) {
		this.approvalDate = approvalDate;
	}

	public String getApprovedBy() {
		return this.approvedBy;
	}

	public void setApprovedBy(String approvedBy) {
		this.approvedBy = approvedBy;
	}

	public Object getAuditLog() {
		return this.auditLog;
	}

	public void setAuditLog(Object auditLog) {
		this.auditLog = auditLog;
	}

	public String getBaseContractNo() {
		return this.baseContractNo;
	}

	public void setBaseContractNo(String baseContractNo) {
		this.baseContractNo = baseContractNo;
	}

	public String getBranchCode() {
		return this.branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	public String getBuBranchCode() {
		return this.buBranchCode;
	}

	public void setBuBranchCode(String buBranchCode) {
		this.buBranchCode = buBranchCode;
	}

	public String getClosedBy() {
		return this.closedBy;
	}

	public void setClosedBy(String closedBy) {
		this.closedBy = closedBy;
	}

	public Date getClosureDate() {
		return this.closureDate;
	}

	public void setClosureDate(Date closureDate) {
		this.closureDate = closureDate;
	}

	public String getCompanyCode() {
		return this.companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public Date getConfigDate() {
		return this.configDate;
	}

	public void setConfigDate(Date configDate) {
		this.configDate = configDate;
	}

	public Date getConfigTxnDate() {
		return this.configTxnDate;
	}

	public void setConfigTxnDate(Date configTxnDate) {
		this.configTxnDate = configTxnDate;
	}

	public String getConfiguredBy() {
		return this.configuredBy;
	}

	public void setConfiguredBy(String configuredBy) {
		this.configuredBy = configuredBy;
	}

	public String getContractNo() {
		return this.contractNo;
	}

	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}

	public String getContractStatus() {
		return this.contractStatus;
	}

	public void setContractStatus(String contractStatus) {
		this.contractStatus = contractStatus;
	}

	public BigDecimal getContractType() {
		return this.contractType;
	}

	public void setContractType(BigDecimal contractType) {
		this.contractType = contractType;
	}

	public String getCustomerCode() {
		return this.customerCode;
	}

	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	public String getFinBySf() {
		return this.finBySf;
	}

	public void setFinBySf(String finBySf) {
		this.finBySf = finBySf;
	}

	public String getGuarantorCode() {
		return this.guarantorCode;
	}

	public void setGuarantorCode(String guarantorCode) {
		this.guarantorCode = guarantorCode;
	}

	public String getInsurByInd() {
		return this.insurByInd;
	}

	public void setInsurByInd(String insurByInd) {
		this.insurByInd = insurByInd;
	}

	public Date getPymtDate() {
		return this.pymtDate;
	}

	public void setPymtDate(Date pymtDate) {
		this.pymtDate = pymtDate;
	}

	public BigDecimal getSanctionHdrId() {
		return this.sanctionHdrId;
	}

	public void setSanctionHdrId(BigDecimal sanctionHdrId) {
		this.sanctionHdrId = sanctionHdrId;
	}

	public BigDecimal getStmtCode() {
		return this.stmtCode;
	}

	public void setStmtCode(BigDecimal stmtCode) {
		this.stmtCode = stmtCode;
	}

	public Date getTxnDate() {
		return this.txnDate;
	}

	public void setTxnDate(Date txnDate) {
		this.txnDate = txnDate;
	}

	public String getVehicleRegnNo() {
		return this.vehicleRegnNo;
	}

	public void setVehicleRegnNo(String vehicleRegnNo) {
		this.vehicleRegnNo = vehicleRegnNo;
	}

}