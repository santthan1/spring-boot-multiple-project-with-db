package in.sf.wcl.entity;

import jakarta.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the PS_TB_LN_CONTRACT_ADDL_INFO database table.
 * 
 */
@Entity
@Table(name="PS_TB_LN_CONTRACT_ADDL_INFO")
@NamedQuery(name="PsTbLnContractAddlInfo.findAll", query="SELECT p FROM PsTbLnContractAddlInfo p")
public class PsTbLnContractAddlInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="AGR_PRINT_NOT_APPL")
	private String agrPrintNotAppl;

	@Column(name="AGREE_PRINT_BY")
	private String agreePrintBy;

	@Column(name="AGREE_PRINT_COUNT")
	private BigDecimal agreePrintCount;

	@Temporal(TemporalType.DATE)
	@Column(name="AGREE_PRINT_DATE")
	private Date agreePrintDate;

	@Column(name="AGREE_PRINT_IND")
	private String agreePrintInd;

	@Column(name="AGREEMENT_DOC_BRANCH")
	private String agreementDocBranch;

	@Column(name="AGREEMENT_DOC_NO")
	private String agreementDocNo;

	@Column(name="AGREEMENT_DOC_SLNO")
	private BigDecimal agreementDocSlno;

	@Temporal(TemporalType.DATE)
	@Column(name="ALLOCATED_DATE")
	private Date allocatedDate;

	@Column(name="APPRAISAL_CATEGORY_CODE")
	private String appraisalCategoryCode;

	@Column(name="AREA_REMARKS")
	private String areaRemarks;

	@Column(name="ASSET_COST")
	private BigDecimal assetCost;

	@Column(name="ASSET_COST_ADDON")
	private BigDecimal assetCostAddon;

	@Column(name="ASSET_COST_IMPL_AMT")
	private BigDecimal assetCostImplAmt;

	@Column(name="AUDIT_LOG")
	private Object auditLog;

	@Column(name="BANK_BRANCH_ID")
	private BigDecimal bankBranchId;

	@Column(name="BANK_CODE")
	private String bankCode;

	@Column(name="BANK_ID")
	private BigDecimal bankId;

	@Column(name="BRW_DIGI_SIGNAUTH_IND")
	private String brwDigiSignauthInd;

	@Column(name="BUSINESS_TYPE")
	private String businessType;

	@Column(name="CANTEEN_STR_DEPT_IND")
	private String canteenStrDeptInd;

	@Column(name="COMPANY_CODE")
	private String companyCode;

	@Column(name="CONTRACT_NO")
	private String contractNo;

	@Column(name="CONTRACT_OTHER_DEDN_AMOUNT")
	private BigDecimal contractOtherDednAmount;

	@Column(name="CONTRACT_OTHER_DEDN_DESC")
	private String contractOtherDednDesc;

	@Column(name="CONTRACT_SCHEME_CODE")
	private String contractSchemeCode;

	@Column(name="CUST_NEW_IND")
	private String custNewInd;

	@Column(name="DDE_APPL_IND")
	private String ddeApplInd;

	@Column(name="DEALER_NEW_IND")
	private String dealerNewInd;

	@Column(name="DEMO_CAR_IND")
	private String demoCarInd;

	@Column(name="DEVIATION_APPR_BY")
	private String deviationApprBy;

	@Column(name="DOCUMENT_CHARGES_APPL")
	private String documentChargesAppl;

	@Column(name="DOCUMENT_CHARGES_REMARKS")
	private String documentChargesRemarks;

	@Column(name="EMI_PAID_BY")
	private String emiPaidBy;

	@Column(name="EMIP_APPL")
	private String emipAppl;

	@Column(name="EMIP_APPL_TO")
	private String emipApplTo;

	@Column(name="FORM_C1_APPL")
	private String formC1Appl;

	@Column(name="FORM_C1_CHARGE_APPL")
	private String formC1ChargeAppl;

	@Column(name="FRESH_KYC_COLLECTED")
	private String freshKycCollected;

	@Column(name="FRESH_KYC_VERIFIED")
	private String freshKycVerified;

	@Column(name="FY_PERIOD")
	private String fyPeriod;

	@Column(name="GUARANTOR_NEW_IND")
	private String guarantorNewInd;

	@Column(name="GUARANTOR_WAIVED_IND")
	private String guarantorWaivedInd;

	@Column(name="IMPLT_ASSET_MAKE_CODE")
	private BigDecimal impltAssetMakeCode;

	@Column(name="IMPLT_ASSET_TYPE_CODE")
	private BigDecimal impltAssetTypeCode;

	@Column(name="INCENT_PAY_IND")
	private String incentPayInd;

	@Column(name="INVOICE_COLLECTED")
	private String invoiceCollected;

	@Column(name="IRR_CONFIRMATION_REMARKS")
	private String irrConfirmationRemarks;

	@Column(name="KEY_OFFICIAL_APPL_IND")
	private String keyOfficialApplInd;

	@Column(name="LAST_DAY_OF_FIRST_INSTL_IND")
	private String lastDayOfFirstInstlInd;

	@Column(name="LTV_PERCENTAGE")
	private BigDecimal ltvPercentage;

	@Column(name="MARKETING_EXECUTIVE")
	private String marketingExecutive;

	@Column(name="MICR_CODE")
	private String micrCode;

	@Column(name="NEFT_RTGS_APPL")
	private String neftRtgsAppl;

	@Column(name="ODS_ACTUAL_USER_ID")
	private String odsActualUserId;

	@Column(name="ODS_ALLOCATED_DATE")
	private Object odsAllocatedDate;

	@Column(name="ODS_APPL")
	private String odsAppl;

	@Temporal(TemporalType.DATE)
	@Column(name="ODS_COMPLETION_DATE")
	private Date odsCompletionDate;

	@Temporal(TemporalType.DATE)
	@Column(name="ODS_SENDBACK_DATE")
	private Date odsSendbackDate;

	@Column(name="ODS_STATUS")
	private String odsStatus;

	@Temporal(TemporalType.DATE)
	@Column(name="ODS_STATUS_DATE")
	private Date odsStatusDate;

	@Column(name="ODS_USER_ID")
	private String odsUserId;

	@Column(name="PA_IND")
	private String paInd;

	@Column(name="PGL_STATUS")
	private String pglStatus;

	@Column(name="PREFERRED_SECTOR_IND")
	private String preferredSectorInd;

	@Column(name="PYMT_MODE")
	private String pymtMode;

	@Column(name="REASON_REMARK")
	private String reasonRemark;

	@Column(name="REFINANCE_CONTRACT_NO")
	private String refinanceContractNo;

	@Column(name="RESIDENTIAL_TYPE")
	private String residentialType;

	@Column(name="RISK_CATEGORY")
	private String riskCategory;

	@Column(name="ROLLOVER_CONTRACT_NO")
	private String rolloverContractNo;

	@Column(name="SAME_DEALER_IND")
	private String sameDealerInd;

	@Column(name="SCHEME_CODE")
	private String schemeCode;

	@Column(name="SCP_BORROWER_APPL_IND")
	private String scpBorrowerApplInd;

	@Column(name="SCP_COBORROWER_APPL_IND")
	private String scpCoborrowerApplInd;

	@Column(name="SCP_IND")
	private String scpInd;

	@Temporal(TemporalType.DATE)
	@Column(name="SECOND_INSTL_DATE")
	private Date secondInstlDate;

	@Column(name="SELL_DIGI_SIGNAUTH_IND")
	private String sellDigiSignauthInd;

	@Column(name="SETTLE_PRINT_COUNT")
	private BigDecimal settlePrintCount;

	@Temporal(TemporalType.DATE)
	@Column(name="SETTLE_PRINT_DATE")
	private Date settlePrintDate;

	@Column(name="SETTLE_PRINT_IND")
	private String settlePrintInd;

	@Column(name="STAMP_CHARGES_PAID_BY")
	private String stampChargesPaidBy;

	@Column(name="STAMP_CHARGES_REMARKS")
	private String stampChargesRemarks;

	@Column(name="STAMP_PAPER_COLL_FRM_CUST")
	private BigDecimal stampPaperCollFrmCust;

	@Column(name="STAMP_PART_COLLECTION_IND")
	private String stampPartCollectionInd;

	@Column(name="SUBV_SCHEME_APPL")
	private String subvSchemeAppl;

	@Column(name="SUBV_SCHEME_CODE")
	private String subvSchemeCode;

	@Column(name="SUBV_SCHEME_DEV_CODE")
	private String subvSchemeDevCode;

	@Column(name="SUBV_SCHEME_DEV_IND")
	private String subvSchemeDevInd;

	@Column(name="SUBV_SCHEME_DEV_REMARKS")
	private String subvSchemeDevRemarks;

	@Column(name="SUBV_SCHEME_ERROR_MESG")
	private String subvSchemeErrorMesg;

	@Column(name="SUBV_SCHEME_ID")
	private String subvSchemeId;

	@Column(name="TCS_BORNE_BY")
	private String tcsBorneBy;

	@Column(name="TRACTOR_INSUR_PAID_BY")
	private String tractorInsurPaidBy;

	@Column(name="TRACTOR_SCHEME_APPL")
	private String tractorSchemeAppl;

	@Column(name="UPLOAD_API_FLAG")
	private String uploadApiFlag;

	public PsTbLnContractAddlInfo() {
	}

	public String getAgrPrintNotAppl() {
		return this.agrPrintNotAppl;
	}

	public void setAgrPrintNotAppl(String agrPrintNotAppl) {
		this.agrPrintNotAppl = agrPrintNotAppl;
	}

	public String getAgreePrintBy() {
		return this.agreePrintBy;
	}

	public void setAgreePrintBy(String agreePrintBy) {
		this.agreePrintBy = agreePrintBy;
	}

	public BigDecimal getAgreePrintCount() {
		return this.agreePrintCount;
	}

	public void setAgreePrintCount(BigDecimal agreePrintCount) {
		this.agreePrintCount = agreePrintCount;
	}

	public Date getAgreePrintDate() {
		return this.agreePrintDate;
	}

	public void setAgreePrintDate(Date agreePrintDate) {
		this.agreePrintDate = agreePrintDate;
	}

	public String getAgreePrintInd() {
		return this.agreePrintInd;
	}

	public void setAgreePrintInd(String agreePrintInd) {
		this.agreePrintInd = agreePrintInd;
	}

	public String getAgreementDocBranch() {
		return this.agreementDocBranch;
	}

	public void setAgreementDocBranch(String agreementDocBranch) {
		this.agreementDocBranch = agreementDocBranch;
	}

	public String getAgreementDocNo() {
		return this.agreementDocNo;
	}

	public void setAgreementDocNo(String agreementDocNo) {
		this.agreementDocNo = agreementDocNo;
	}

	public BigDecimal getAgreementDocSlno() {
		return this.agreementDocSlno;
	}

	public void setAgreementDocSlno(BigDecimal agreementDocSlno) {
		this.agreementDocSlno = agreementDocSlno;
	}

	public Date getAllocatedDate() {
		return this.allocatedDate;
	}

	public void setAllocatedDate(Date allocatedDate) {
		this.allocatedDate = allocatedDate;
	}

	public String getAppraisalCategoryCode() {
		return this.appraisalCategoryCode;
	}

	public void setAppraisalCategoryCode(String appraisalCategoryCode) {
		this.appraisalCategoryCode = appraisalCategoryCode;
	}

	public String getAreaRemarks() {
		return this.areaRemarks;
	}

	public void setAreaRemarks(String areaRemarks) {
		this.areaRemarks = areaRemarks;
	}

	public BigDecimal getAssetCost() {
		return this.assetCost;
	}

	public void setAssetCost(BigDecimal assetCost) {
		this.assetCost = assetCost;
	}

	public BigDecimal getAssetCostAddon() {
		return this.assetCostAddon;
	}

	public void setAssetCostAddon(BigDecimal assetCostAddon) {
		this.assetCostAddon = assetCostAddon;
	}

	public BigDecimal getAssetCostImplAmt() {
		return this.assetCostImplAmt;
	}

	public void setAssetCostImplAmt(BigDecimal assetCostImplAmt) {
		this.assetCostImplAmt = assetCostImplAmt;
	}

	public Object getAuditLog() {
		return this.auditLog;
	}

	public void setAuditLog(Object auditLog) {
		this.auditLog = auditLog;
	}

	public BigDecimal getBankBranchId() {
		return this.bankBranchId;
	}

	public void setBankBranchId(BigDecimal bankBranchId) {
		this.bankBranchId = bankBranchId;
	}

	public String getBankCode() {
		return this.bankCode;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	public BigDecimal getBankId() {
		return this.bankId;
	}

	public void setBankId(BigDecimal bankId) {
		this.bankId = bankId;
	}

	public String getBrwDigiSignauthInd() {
		return this.brwDigiSignauthInd;
	}

	public void setBrwDigiSignauthInd(String brwDigiSignauthInd) {
		this.brwDigiSignauthInd = brwDigiSignauthInd;
	}

	public String getBusinessType() {
		return this.businessType;
	}

	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}

	public String getCanteenStrDeptInd() {
		return this.canteenStrDeptInd;
	}

	public void setCanteenStrDeptInd(String canteenStrDeptInd) {
		this.canteenStrDeptInd = canteenStrDeptInd;
	}

	public String getCompanyCode() {
		return this.companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getContractNo() {
		return this.contractNo;
	}

	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}

	public BigDecimal getContractOtherDednAmount() {
		return this.contractOtherDednAmount;
	}

	public void setContractOtherDednAmount(BigDecimal contractOtherDednAmount) {
		this.contractOtherDednAmount = contractOtherDednAmount;
	}

	public String getContractOtherDednDesc() {
		return this.contractOtherDednDesc;
	}

	public void setContractOtherDednDesc(String contractOtherDednDesc) {
		this.contractOtherDednDesc = contractOtherDednDesc;
	}

	public String getContractSchemeCode() {
		return this.contractSchemeCode;
	}

	public void setContractSchemeCode(String contractSchemeCode) {
		this.contractSchemeCode = contractSchemeCode;
	}

	public String getCustNewInd() {
		return this.custNewInd;
	}

	public void setCustNewInd(String custNewInd) {
		this.custNewInd = custNewInd;
	}

	public String getDdeApplInd() {
		return this.ddeApplInd;
	}

	public void setDdeApplInd(String ddeApplInd) {
		this.ddeApplInd = ddeApplInd;
	}

	public String getDealerNewInd() {
		return this.dealerNewInd;
	}

	public void setDealerNewInd(String dealerNewInd) {
		this.dealerNewInd = dealerNewInd;
	}

	public String getDemoCarInd() {
		return this.demoCarInd;
	}

	public void setDemoCarInd(String demoCarInd) {
		this.demoCarInd = demoCarInd;
	}

	public String getDeviationApprBy() {
		return this.deviationApprBy;
	}

	public void setDeviationApprBy(String deviationApprBy) {
		this.deviationApprBy = deviationApprBy;
	}

	public String getDocumentChargesAppl() {
		return this.documentChargesAppl;
	}

	public void setDocumentChargesAppl(String documentChargesAppl) {
		this.documentChargesAppl = documentChargesAppl;
	}

	public String getDocumentChargesRemarks() {
		return this.documentChargesRemarks;
	}

	public void setDocumentChargesRemarks(String documentChargesRemarks) {
		this.documentChargesRemarks = documentChargesRemarks;
	}

	public String getEmiPaidBy() {
		return this.emiPaidBy;
	}

	public void setEmiPaidBy(String emiPaidBy) {
		this.emiPaidBy = emiPaidBy;
	}

	public String getEmipAppl() {
		return this.emipAppl;
	}

	public void setEmipAppl(String emipAppl) {
		this.emipAppl = emipAppl;
	}

	public String getEmipApplTo() {
		return this.emipApplTo;
	}

	public void setEmipApplTo(String emipApplTo) {
		this.emipApplTo = emipApplTo;
	}

	public String getFormC1Appl() {
		return this.formC1Appl;
	}

	public void setFormC1Appl(String formC1Appl) {
		this.formC1Appl = formC1Appl;
	}

	public String getFormC1ChargeAppl() {
		return this.formC1ChargeAppl;
	}

	public void setFormC1ChargeAppl(String formC1ChargeAppl) {
		this.formC1ChargeAppl = formC1ChargeAppl;
	}

	public String getFreshKycCollected() {
		return this.freshKycCollected;
	}

	public void setFreshKycCollected(String freshKycCollected) {
		this.freshKycCollected = freshKycCollected;
	}

	public String getFreshKycVerified() {
		return this.freshKycVerified;
	}

	public void setFreshKycVerified(String freshKycVerified) {
		this.freshKycVerified = freshKycVerified;
	}

	public String getFyPeriod() {
		return this.fyPeriod;
	}

	public void setFyPeriod(String fyPeriod) {
		this.fyPeriod = fyPeriod;
	}

	public String getGuarantorNewInd() {
		return this.guarantorNewInd;
	}

	public void setGuarantorNewInd(String guarantorNewInd) {
		this.guarantorNewInd = guarantorNewInd;
	}

	public String getGuarantorWaivedInd() {
		return this.guarantorWaivedInd;
	}

	public void setGuarantorWaivedInd(String guarantorWaivedInd) {
		this.guarantorWaivedInd = guarantorWaivedInd;
	}

	public BigDecimal getImpltAssetMakeCode() {
		return this.impltAssetMakeCode;
	}

	public void setImpltAssetMakeCode(BigDecimal impltAssetMakeCode) {
		this.impltAssetMakeCode = impltAssetMakeCode;
	}

	public BigDecimal getImpltAssetTypeCode() {
		return this.impltAssetTypeCode;
	}

	public void setImpltAssetTypeCode(BigDecimal impltAssetTypeCode) {
		this.impltAssetTypeCode = impltAssetTypeCode;
	}

	public String getIncentPayInd() {
		return this.incentPayInd;
	}

	public void setIncentPayInd(String incentPayInd) {
		this.incentPayInd = incentPayInd;
	}

	public String getInvoiceCollected() {
		return this.invoiceCollected;
	}

	public void setInvoiceCollected(String invoiceCollected) {
		this.invoiceCollected = invoiceCollected;
	}

	public String getIrrConfirmationRemarks() {
		return this.irrConfirmationRemarks;
	}

	public void setIrrConfirmationRemarks(String irrConfirmationRemarks) {
		this.irrConfirmationRemarks = irrConfirmationRemarks;
	}

	public String getKeyOfficialApplInd() {
		return this.keyOfficialApplInd;
	}

	public void setKeyOfficialApplInd(String keyOfficialApplInd) {
		this.keyOfficialApplInd = keyOfficialApplInd;
	}

	public String getLastDayOfFirstInstlInd() {
		return this.lastDayOfFirstInstlInd;
	}

	public void setLastDayOfFirstInstlInd(String lastDayOfFirstInstlInd) {
		this.lastDayOfFirstInstlInd = lastDayOfFirstInstlInd;
	}

	public BigDecimal getLtvPercentage() {
		return this.ltvPercentage;
	}

	public void setLtvPercentage(BigDecimal ltvPercentage) {
		this.ltvPercentage = ltvPercentage;
	}

	public String getMarketingExecutive() {
		return this.marketingExecutive;
	}

	public void setMarketingExecutive(String marketingExecutive) {
		this.marketingExecutive = marketingExecutive;
	}

	public String getMicrCode() {
		return this.micrCode;
	}

	public void setMicrCode(String micrCode) {
		this.micrCode = micrCode;
	}

	public String getNeftRtgsAppl() {
		return this.neftRtgsAppl;
	}

	public void setNeftRtgsAppl(String neftRtgsAppl) {
		this.neftRtgsAppl = neftRtgsAppl;
	}

	public String getOdsActualUserId() {
		return this.odsActualUserId;
	}

	public void setOdsActualUserId(String odsActualUserId) {
		this.odsActualUserId = odsActualUserId;
	}

	public Object getOdsAllocatedDate() {
		return this.odsAllocatedDate;
	}

	public void setOdsAllocatedDate(Object odsAllocatedDate) {
		this.odsAllocatedDate = odsAllocatedDate;
	}

	public String getOdsAppl() {
		return this.odsAppl;
	}

	public void setOdsAppl(String odsAppl) {
		this.odsAppl = odsAppl;
	}

	public Date getOdsCompletionDate() {
		return this.odsCompletionDate;
	}

	public void setOdsCompletionDate(Date odsCompletionDate) {
		this.odsCompletionDate = odsCompletionDate;
	}

	public Date getOdsSendbackDate() {
		return this.odsSendbackDate;
	}

	public void setOdsSendbackDate(Date odsSendbackDate) {
		this.odsSendbackDate = odsSendbackDate;
	}

	public String getOdsStatus() {
		return this.odsStatus;
	}

	public void setOdsStatus(String odsStatus) {
		this.odsStatus = odsStatus;
	}

	public Date getOdsStatusDate() {
		return this.odsStatusDate;
	}

	public void setOdsStatusDate(Date odsStatusDate) {
		this.odsStatusDate = odsStatusDate;
	}

	public String getOdsUserId() {
		return this.odsUserId;
	}

	public void setOdsUserId(String odsUserId) {
		this.odsUserId = odsUserId;
	}

	public String getPaInd() {
		return this.paInd;
	}

	public void setPaInd(String paInd) {
		this.paInd = paInd;
	}

	public String getPglStatus() {
		return this.pglStatus;
	}

	public void setPglStatus(String pglStatus) {
		this.pglStatus = pglStatus;
	}

	public String getPreferredSectorInd() {
		return this.preferredSectorInd;
	}

	public void setPreferredSectorInd(String preferredSectorInd) {
		this.preferredSectorInd = preferredSectorInd;
	}

	public String getPymtMode() {
		return this.pymtMode;
	}

	public void setPymtMode(String pymtMode) {
		this.pymtMode = pymtMode;
	}

	public String getReasonRemark() {
		return this.reasonRemark;
	}

	public void setReasonRemark(String reasonRemark) {
		this.reasonRemark = reasonRemark;
	}

	public String getRefinanceContractNo() {
		return this.refinanceContractNo;
	}

	public void setRefinanceContractNo(String refinanceContractNo) {
		this.refinanceContractNo = refinanceContractNo;
	}

	public String getResidentialType() {
		return this.residentialType;
	}

	public void setResidentialType(String residentialType) {
		this.residentialType = residentialType;
	}

	public String getRiskCategory() {
		return this.riskCategory;
	}

	public void setRiskCategory(String riskCategory) {
		this.riskCategory = riskCategory;
	}

	public String getRolloverContractNo() {
		return this.rolloverContractNo;
	}

	public void setRolloverContractNo(String rolloverContractNo) {
		this.rolloverContractNo = rolloverContractNo;
	}

	public String getSameDealerInd() {
		return this.sameDealerInd;
	}

	public void setSameDealerInd(String sameDealerInd) {
		this.sameDealerInd = sameDealerInd;
	}

	public String getSchemeCode() {
		return this.schemeCode;
	}

	public void setSchemeCode(String schemeCode) {
		this.schemeCode = schemeCode;
	}

	public String getScpBorrowerApplInd() {
		return this.scpBorrowerApplInd;
	}

	public void setScpBorrowerApplInd(String scpBorrowerApplInd) {
		this.scpBorrowerApplInd = scpBorrowerApplInd;
	}

	public String getScpCoborrowerApplInd() {
		return this.scpCoborrowerApplInd;
	}

	public void setScpCoborrowerApplInd(String scpCoborrowerApplInd) {
		this.scpCoborrowerApplInd = scpCoborrowerApplInd;
	}

	public String getScpInd() {
		return this.scpInd;
	}

	public void setScpInd(String scpInd) {
		this.scpInd = scpInd;
	}

	public Date getSecondInstlDate() {
		return this.secondInstlDate;
	}

	public void setSecondInstlDate(Date secondInstlDate) {
		this.secondInstlDate = secondInstlDate;
	}

	public String getSellDigiSignauthInd() {
		return this.sellDigiSignauthInd;
	}

	public void setSellDigiSignauthInd(String sellDigiSignauthInd) {
		this.sellDigiSignauthInd = sellDigiSignauthInd;
	}

	public BigDecimal getSettlePrintCount() {
		return this.settlePrintCount;
	}

	public void setSettlePrintCount(BigDecimal settlePrintCount) {
		this.settlePrintCount = settlePrintCount;
	}

	public Date getSettlePrintDate() {
		return this.settlePrintDate;
	}

	public void setSettlePrintDate(Date settlePrintDate) {
		this.settlePrintDate = settlePrintDate;
	}

	public String getSettlePrintInd() {
		return this.settlePrintInd;
	}

	public void setSettlePrintInd(String settlePrintInd) {
		this.settlePrintInd = settlePrintInd;
	}

	public String getStampChargesPaidBy() {
		return this.stampChargesPaidBy;
	}

	public void setStampChargesPaidBy(String stampChargesPaidBy) {
		this.stampChargesPaidBy = stampChargesPaidBy;
	}

	public String getStampChargesRemarks() {
		return this.stampChargesRemarks;
	}

	public void setStampChargesRemarks(String stampChargesRemarks) {
		this.stampChargesRemarks = stampChargesRemarks;
	}

	public BigDecimal getStampPaperCollFrmCust() {
		return this.stampPaperCollFrmCust;
	}

	public void setStampPaperCollFrmCust(BigDecimal stampPaperCollFrmCust) {
		this.stampPaperCollFrmCust = stampPaperCollFrmCust;
	}

	public String getStampPartCollectionInd() {
		return this.stampPartCollectionInd;
	}

	public void setStampPartCollectionInd(String stampPartCollectionInd) {
		this.stampPartCollectionInd = stampPartCollectionInd;
	}

	public String getSubvSchemeAppl() {
		return this.subvSchemeAppl;
	}

	public void setSubvSchemeAppl(String subvSchemeAppl) {
		this.subvSchemeAppl = subvSchemeAppl;
	}

	public String getSubvSchemeCode() {
		return this.subvSchemeCode;
	}

	public void setSubvSchemeCode(String subvSchemeCode) {
		this.subvSchemeCode = subvSchemeCode;
	}

	public String getSubvSchemeDevCode() {
		return this.subvSchemeDevCode;
	}

	public void setSubvSchemeDevCode(String subvSchemeDevCode) {
		this.subvSchemeDevCode = subvSchemeDevCode;
	}

	public String getSubvSchemeDevInd() {
		return this.subvSchemeDevInd;
	}

	public void setSubvSchemeDevInd(String subvSchemeDevInd) {
		this.subvSchemeDevInd = subvSchemeDevInd;
	}

	public String getSubvSchemeDevRemarks() {
		return this.subvSchemeDevRemarks;
	}

	public void setSubvSchemeDevRemarks(String subvSchemeDevRemarks) {
		this.subvSchemeDevRemarks = subvSchemeDevRemarks;
	}

	public String getSubvSchemeErrorMesg() {
		return this.subvSchemeErrorMesg;
	}

	public void setSubvSchemeErrorMesg(String subvSchemeErrorMesg) {
		this.subvSchemeErrorMesg = subvSchemeErrorMesg;
	}

	public String getSubvSchemeId() {
		return this.subvSchemeId;
	}

	public void setSubvSchemeId(String subvSchemeId) {
		this.subvSchemeId = subvSchemeId;
	}

	public String getTcsBorneBy() {
		return this.tcsBorneBy;
	}

	public void setTcsBorneBy(String tcsBorneBy) {
		this.tcsBorneBy = tcsBorneBy;
	}

	public String getTractorInsurPaidBy() {
		return this.tractorInsurPaidBy;
	}

	public void setTractorInsurPaidBy(String tractorInsurPaidBy) {
		this.tractorInsurPaidBy = tractorInsurPaidBy;
	}

	public String getTractorSchemeAppl() {
		return this.tractorSchemeAppl;
	}

	public void setTractorSchemeAppl(String tractorSchemeAppl) {
		this.tractorSchemeAppl = tractorSchemeAppl;
	}

	public String getUploadApiFlag() {
		return this.uploadApiFlag;
	}

	public void setUploadApiFlag(String uploadApiFlag) {
		this.uploadApiFlag = uploadApiFlag;
	}

}