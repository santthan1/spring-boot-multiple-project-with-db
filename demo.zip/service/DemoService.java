package com.example.demo.service;

import com.example.demo.entity.Demo;

public interface DemoService extends GenericService<Demo, Long> {
}