package com.example.demo.service.impl;

import com.example.demo.dao.DemoRepository;
import com.example.demo.dto.DemoDTO;
import com.example.demo.entity.Demo;
import com.example.demo.mapper.DemoMapper;
import com.example.demo.service.DemoService;
import org.mapstruct.factory.Mappers;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class DemoServiceImpl implements DemoService {
    private final DemoRepository repository;

    public DemoServiceImpl(DemoRepository repository) {
        this.repository = repository;
    }

    @Override
    public Demo save(Demo entity) {
        return repository.save(entity);
    }

    @Override
    public List<Demo> save(List<Demo> entities) {
        return (List<Demo>) repository.saveAll(entities);
    }

    @Override
    public void deleteById(Long id) {
        repository.deleteById(id);
    }

    @Override
    public Optional<Demo> findById(Long id) {
        return repository.findById(id);
    }

    @Override
    public List<Demo> findAll() {
        return (List<Demo>) repository.findAll();
    }

    @Override
    public Page<Demo> findAll(Pageable pageable) {
        Page<Demo> entityPage = repository.findAll(pageable);
        List<Demo> entities = entityPage.getContent();
        return new PageImpl<>(entities, pageable, entityPage.getTotalElements());
    }

    @Override
    public Demo update(Demo entity, Long id) {
        Optional<Demo> optional = findById(id);
        if (optional.isPresent()) {
            return save(entity);
        }
        return null;
    }
}