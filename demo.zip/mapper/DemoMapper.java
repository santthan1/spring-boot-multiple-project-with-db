package com.example.demo.mapper;

import com.example.demo.dto.DemoDTO;
import com.example.demo.entity.Demo;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface DemoMapper extends GenericMapper<Demo, DemoDTO> {
    @Override
    @Mapping(target = "id", ignore = false)
    Demo asEntity(DemoDTO dto);
}