package com.example.demo.controller.impl;

import com.example.demo.controller.DemoController;
import com.example.demo.dto.DemoDTO;
import com.example.demo.entity.Demo;
import com.example.demo.mapper.DemoMapper;
import com.example.demo.service.DemoService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RequestMapping("/api/demo")
@RestController
public class DemoControllerImpl implements DemoController {
    private final DemoService demoService;
    private final DemoMapper demoMapper;

    public DemoControllerImpl(DemoService demoService, DemoMapper demoMapper) {
        this.demoService = demoService;
        this.demoMapper = demoMapper;
    }

    @Override
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public DemoDTO save(@RequestBody DemoDTO demoDTO) {
        Demo demo = demoMapper.asEntity(demoDTO);
        return demoMapper.asDTO(demoService.save(demo));
    }

    @Override
    @GetMapping("/{id}")
    public DemoDTO findById(@PathVariable("id") long id) {
        Demo demo = demoService.findById(id).orElse(null);
        return demoMapper.asDTO(demo);
    }

    @Override
    @DeleteMapping("/{id}")
    public void delete(@PathVariable("id") long id) {
        demoService.deleteById(id);
    }

    @Override
    @GetMapping
    public List<DemoDTO> list() {
        return demoMapper.asDTOList(demoService.findAll());
    }

    @Override
    @GetMapping("/page-query")
    public Page<DemoDTO> pageQuery(Pageable pageable) {
        Page<Demo> demoPage = demoService.findAll(pageable);
        List<DemoDTO> dtoList = demoPage
                .stream()
                .map(demoMapper::asDTO).collect(Collectors.toList());
        return new PageImpl<>(dtoList, pageable, demoPage.getTotalElements());
    }

    @Override
    @PutMapping("/{id}")
    public DemoDTO update(@RequestBody DemoDTO demoDTO, @PathVariable("id") long id) {
        Demo demo = demoMapper.asEntity(demoDTO);
        return demoMapper.asDTO(demoService.update(demo, id));
    }
}