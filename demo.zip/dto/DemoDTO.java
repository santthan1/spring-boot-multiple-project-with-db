package com.example.demo.dto;

import javax.persistence.Id;

public class DemoDTO  {
    @Id
    private long id;
    private String name;

    public DemoDTO() {
    }

    public void setId(long id) {
        this.id = id;
    }

    public Long getId() {
        return this.id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public DemoDTO(long id, String name) {
        this.id = id;
        this.name = name;
    }

    public String getName() {
        return this.name;
    }
}