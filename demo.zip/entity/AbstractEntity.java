package com.example.demo.entity;

public interface AbstractEntity<E> { E getId(); }